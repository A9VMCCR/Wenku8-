/* -*- Mode: java; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.javascript;

import static org.mozilla.javascript.ClassDescriptor.Destination.PROTO;

import java.io.Serial;

/**
 * This class implements the Boolean native object. See ECMA 15.6.
 *
 * @author Norris Boyd
 */
final class NativeBoolean extends ScriptableObject {
    @Serial private static final long serialVersionUID = -3716996899943880933L;

    private static final String CLASS_NAME = "Boolean";

    private static final ClassDescriptor DESCRIPTOR;

    static {
        DESCRIPTOR =
                new ClassDescriptor.Builder(
                                CLASS_NAME,
                                1,
                                NativeBoolean::js_constructorFunc,
                                NativeBoolean::js_constructor)
                        .withMethod(PROTO, "toString", 0, NativeBoolean::js_toString)
                        .withMethod(PROTO, "toSource", 0, NativeBoolean::js_toSource)
                        .withMethod(PROTO, "valueOf", 0, NativeBoolean::js_valueOf)
                        .build();
    }

    private final boolean booleanValue;

    static void init(Context cx, VarScope scope, boolean sealed) {
        // Boolean is an unusual object in that the prototype is itself a Boolean
        DESCRIPTOR.buildConstructor(cx, scope, new NativeBoolean(false), sealed);
    }

    NativeBoolean(boolean b) {
        booleanValue = b;
    }

    @Override
    public String getClassName() {
        return CLASS_NAME;
    }

    private static boolean toValue(Object thisObj) {
        return ScriptableObject.ensureType(thisObj, NativeBoolean.class, "Boolean").booleanValue;
    }

    @Override
    public Object getDefaultValue(Class<?> typeHint) {
        // This is actually non-ECMA, but will be proposed
        // as a change in round 2.
        if (typeHint == ScriptRuntime.BooleanClass) return ScriptRuntime.wrapBoolean(booleanValue);
        return super.getDefaultValue(typeHint);
    }

    private static Object js_constructorFunc(
            Context cx, JSFunction f, Object nt, VarScope s, Object thisObj, Object[] args) {
        boolean b = ScriptRuntime.toBoolean(args.length > 0 ? args[0] : Undefined.instance);
        return ScriptRuntime.wrapBoolean(b);
    }

    private static NativeBoolean js_constructor(
            Context cx, JSFunction fun, Object nt, VarScope s, Object thisObj, Object[] args) {
        boolean b = ScriptRuntime.toBoolean(args.length > 0 ? args[0] : Undefined.instance);
        var res = new NativeBoolean(b);
        res.setPrototype((Scriptable) fun.getPrototypeProperty());
        res.setParentScope(s);
        return res;
    }

    private static String js_toString(
            Context cx, JSFunction f, Object nt, VarScope s, Object thisObj, Object[] args) {
        return toValue(thisObj) ? "true" : "false";
    }

    private static Object js_valueOf(
            Context cx, JSFunction f, Object nt, VarScope s, Object thisObj, Object[] args) {
        return toValue(thisObj);
    }

    private static Object js_toSource(
            Context cx, JSFunction f, Object nt, VarScope s, Object thisObj, Object[] args) {
        return "(new Boolean(" + ScriptRuntime.toString(toValue(thisObj)) + "))";
    }
}
