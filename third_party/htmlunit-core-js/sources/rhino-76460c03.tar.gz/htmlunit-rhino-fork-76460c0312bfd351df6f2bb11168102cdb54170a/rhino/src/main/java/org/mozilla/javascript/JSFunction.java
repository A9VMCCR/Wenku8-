package org.mozilla.javascript;

import java.util.EnumSet;

import org.mozilla.javascript.ast.FunctionNode;
import org.mozilla.javascript.debug.DebuggableScript;

/**
 * Represents a JavaScript function built upon a a {@link JSDescriptor}. All the immutable metadata
 * associated with the function is stored on the descriptor, with only the lexically bound this, the
 * home object required for super calls, and mutable properties held on the function object itself.
 */
public class JSFunction extends BaseFunction implements ScriptOrFn<JSFunction> {
    private final JSDescriptor<JSFunction> descriptor;
    private final Scriptable lexicalThis;
    private final Scriptable homeObject;

    public JSFunction(
            Context cx,
            VarScope scope,
            JSDescriptor<JSFunction> descriptor,
            Scriptable lexicalThis,
            Scriptable homeObject) {
        this.descriptor = descriptor;
        this.lexicalThis = lexicalThis;
        this.homeObject = homeObject;
        ScriptRuntime.setFunctionProtoAndParent(this, cx, scope, descriptor.isES6Generator());
        if (!descriptor.isShorthand()) {
            setupDefaultPrototype(scope);
        }
    }

    JSFunction(
            VarScope scope,
            JSDescriptor<JSFunction> descriptor,
            Scriptable lexicalThis,
            Scriptable homeObject) {
        this.descriptor = descriptor;
        this.lexicalThis = lexicalThis;
        this.homeObject = homeObject;
        setParentScope(scope);
        setPrototype(ScriptableObject.getFunctionPrototype(scope));
    }

    @Override
    protected void setPrototypeProperty(Object prototype) {
        super.setPrototypeProperty(prototype);
    }

    @Override
    public VarScope getDeclarationScope() {
        return this.getParentScope();
    }

    @Override
    public JSDescriptor<JSFunction> getDescriptor() {
        return descriptor;
    }

    @Override
    final String decompile(int indent, EnumSet<DecompilerFlag> flags) {
        return descriptor.getRawSource();
    }

    public boolean isShorthand() {
        return descriptor.isShorthand();
    }

    public boolean isStrict() {
        return descriptor.isStrict();
    }

    @Override
    public int getArity() {
        return descriptor.getArity();
    }

    public DebuggableScript getDebuggableView() {
        return null;
    }

    protected int getLanguageVersion() {
        return descriptor.getLanguageVersion();
    }

    @Override
    protected boolean hasPrototypeProperty() {
        return true;
    }

    @Override
    protected boolean isGeneratorFunction() {
        return descriptor.isES6Generator();
    }

    @Override
    public int getLength() {
        return descriptor.getArity();
    }

    protected int getParamAndVarCount() {
        return descriptor.getParamAndVarCount();
    }

    protected int getParamCount() {
        int count = descriptor.getParamCount();
        if (descriptor.hasRestArg()) {
            return count - 1;
        }
        return count;
    }

    protected boolean getParamOrVarConst(int index) {
        return descriptor.getParamOrVarConst(index);
    }

    protected String getParamOrVarName(int index) {
        return descriptor.getParamOrVarName(index);
    }

    public String getRawSource() {
        return descriptor.getRawSource();
    }

    @Override
    protected void createPrototypeProperty() {
        if (descriptor.hasPrototype()) {
            super.createPrototypeProperty();
        }
    }

    JSCode<JSFunction> getCode() {
        return descriptor.getCode();
    }

    JSCode<JSFunction> getConstructor() {
        return descriptor.getConstructor();
    }

    @Override
    public Object call(Context cx, VarScope scope, Scriptable thisObj, Object[] args) {
        if (!ScriptRuntime.hasTopCall(cx)) {
            return ScriptRuntime.doTopCall(this, cx, scope, thisObj, args, isStrict());
        }
        var realThis = getThisObj(thisObj);
        return descriptor.getCode().execute(cx, this, Undefined.instance, scope, realThis, args);
    }

    public final Scriptable getThisObj(Scriptable thisObj) {
        if (descriptor.hasLexicalThis()) {
            return lexicalThis;
        } else if (!descriptor.isStrict() && (thisObj == null || Undefined.isUndefined(thisObj))) {
            // legado
            Context cx = Context.getCurrentContext();
            if (cx != null
                    && cx.hasFeature(Context.FEATURE_LEGADO_DYNAMIC_DEFAULT_THIS)
                    && ScriptRuntime.hasTopCall(cx)) {
                Scriptable dynThis =
                        ScriptableObject.getTopLevelScope(ScriptRuntime.getTopCallScope(cx))
                                .getGlobalThis();
                if (dynThis != null) {
                    return dynThis;
                }
            }
            // end legado
            var res = ScriptableObject.getTopLevelScope(getDeclarationScope()).getGlobalThis();
            return res;
        } else {
            return thisObj;
        }
    }

    @Override
    public Scriptable construct(Context cx, VarScope scope, Object[] args) {
        if (!ScriptRuntime.hasTopCall(cx)) {
            return (Scriptable)
                    ScriptRuntime.doTopCall(
                            (lcx, lscope, lthisObj, largs) -> construct(lcx, lscope, largs),
                            cx,
                            scope,
                            null,
                            args,
                            isStrict());
        }
        if (descriptor.getConstructor() == null) {
            throw ScriptRuntime.typeErrorById("msg.not.ctor", getFunctionName());
        }
        var thisObj = homeObject == null ? createObject(cx, scope) : null;
        // Pass `this` in as new.target for now. This can change when
        // the public `construct` signature changes.
        var res = descriptor.getConstructor().execute(cx, this, this, scope, thisObj, args);
        if (res instanceof Scriptable) {
            thisObj = (Scriptable) res;
        }
        return thisObj;
    }

    public boolean isScript() {
        return descriptor.isScript();
    }

    @Override
    protected boolean hasDefaultParameters() {
        return descriptor.hasDefaultParameters();
    }

    public boolean hasFunctionNamed(String name) {
        return descriptor.hasFunctionNamed(name);
    }

    @Override
    public String getFunctionName() {
        return descriptor.getName();
    }

    public Object resumeGenerator(
            Context cx, VarScope scope, int operation, Object state, Object value) {
        return descriptor.getCode().resume(cx, this, state, scope, operation, value);
    }

    @Override
    public Scriptable getHomeObject() {
        return homeObject;
    }

    @Override
    public void setHomeObject(Scriptable homeObject) {
        throw new UnsupportedOperationException("Cannot set home object on JS function.");
    }

    public Scriptable getFunctionThis(Scriptable functionThis) {
        if (descriptor.hasLexicalThis()) {
            return this.lexicalThis;
        } else {
            return functionThis;
        }
    }

    /** Create script from compiled bytecode. */
    public static JSScript createScript(
            JSDescriptor<JSScript> desc, Scriptable homeObject, Object staticSecurityDomain) {
        assert (desc.getSecurityDomain() == staticSecurityDomain);
        assert desc.isScript();
        return new JSScript(desc, homeObject);
    }

    /** Create function compiled from Function(...) constructor. */
    public static JSFunction createFunction(
            Context cx,
            VarScope scope,
            JSDescriptor<JSFunction> desc,
            Scriptable homeObject,
            Object staticSecurityDomain) {
        assert (desc.getSecurityDomain() == staticSecurityDomain);
        JSFunction f = new JSFunction(cx, scope, desc, null, homeObject);
        return f;
    }

    /** Create function embedded in script or another function. */
    static JSFunction createFunction(
            Context cx, VarScope scope, JSDescriptor<?> parent, int index, Scriptable homeObject) {
        JSDescriptor<JSFunction> desc = parent.getFunction(index);
        JSFunction f = new JSFunction(cx, scope, desc, null, homeObject);
        return f;
    }

    @Override
    public boolean isConstructor() {
        return descriptor.getConstructor() != null;
    }

    // HtmlUnit
    Object callerObj;

    @Override
    Object getCaller() {
        if (isStrict() || getDescriptor().getFunctionType() == FunctionNode.ARROW_FUNCTION) {
            throw ScriptRuntime.typeErrorById("msg.op.not.allowed");
        }
        return callerObj;
    }

    void setCaller(Object caller) {
        if (isStrict()) {
            throw ScriptRuntime.typeErrorById("msg.op.not.allowed");
        }
    }


    void setCallerObj(Object caller) {
        callerObj = caller;
    }
    // HtmlUnit
}
