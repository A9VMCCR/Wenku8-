/* -*- Mode: java; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.javascript;

import java.io.Serial;

public final class NativeStringIterator extends ES6Iterator {
    @Serial private static final long serialVersionUID = 6709689999500242078L;
    private static final String ITERATOR_TAG = "StringIterator";

    private static final ClassDescriptor DESCRIPTOR =
            ES6Iterator.makeDescriptor(ITERATOR_TAG, "String Iterator");

    static void init(Context cx, VarScope scope, boolean sealed) {
        ES6Iterator.initialize(
                DESCRIPTOR, cx, (TopLevel) scope, new NativeStringIterator(), sealed, ITERATOR_TAG);
    }

    /** Only for constructing the prototype object. */
    private NativeStringIterator() {
        super();
    }

    NativeStringIterator(VarScope scope, Object stringLike) {
        super(scope, ITERATOR_TAG);
        this.index = 0;
        this.string = ScriptRuntime.toString(stringLike);
    }

    @Override
    public String getClassName() {
        return "String Iterator";
    }

    @Override
    protected boolean isDone(Context cx, VarScope scope) {
        return index >= string.length();
    }

    @Override
    protected Object nextValue(Context cx, VarScope scope) {
        int newIndex = string.offsetByCodePoints(index, 1);
        Object value = string.substring(index, newIndex);
        index = newIndex;
        return value;
    }

    @Override
    protected String getTag() {
        return ITERATOR_TAG;
    }

    private String string;
    private int index;
}
