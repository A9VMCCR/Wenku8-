/* -*- Mode: java; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.javascript;

import static org.mozilla.javascript.UniqueTag.DOUBLE_MARK;

import java.io.PrintStream;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Objects;
import org.mozilla.javascript.ScriptRuntime.NoSuchMethodShim;
import org.mozilla.javascript.ast.FunctionNode;
import org.mozilla.javascript.ast.ScriptNode;
import org.mozilla.javascript.debug.DebuggableScript;

public final class Interpreter extends AInterpreter<CallFrame, InterpreterData<?>> {

    static final int EXCEPTION_TRY_START_SLOT = 0;
    static final int EXCEPTION_TRY_END_SLOT = 1;
    static final int EXCEPTION_HANDLER_SLOT = 2;
    static final int EXCEPTION_TYPE_SLOT = 3;
    static final int EXCEPTION_LOCAL_SLOT = 4;
    static final int EXCEPTION_SCOPE_SLOT = 5;
    // SLOT_SIZE: space for try start/end, handler, start, handler type,
    //            exception local and scope local
    static final int EXCEPTION_SLOT_SIZE = 6;

    static boolean compareDescs(JSDescriptor i1, JSDescriptor i2) {
        return i1 == i2 || Objects.equals(getRawSource(i1), getRawSource(i2));
    }

    private static CallFrame captureFrameForGenerator(CallFrame frame) {
        frame.frozen = true;
        CallFrame result = frame.captureForGenerator();
        frame.frozen = false;

        return result;
    }

    static {
        // Checks for byte code consistencies, good compiler can eliminate them

        if (Token.LAST_BYTECODE_TOKEN > 127) {
            String str = "Violation of Token.LAST_BYTECODE_TOKEN <= 127";
            System.err.println(str);
            throw new IllegalStateException(str);
        }
        if (Icode.MIN_ICODE < -128) {
            String str = "Violation of Interpreter.MIN_ICODE >= -128";
            System.err.println(str);
            throw new IllegalStateException(str);
        }

        RhinoException.registerInterpreterMethod(Interpreter.class, "interpretLoop");
    }

    private static class InterpreterCompilationResult<T extends ScriptOrFn<T>>
            implements CompilationResult<T> {
        private final JSDescriptor<T> descriptor;
        private final Scriptable homeObject;

        InterpreterCompilationResult(JSDescriptor<T> descriptor, Scriptable homeObject) {
            this.descriptor = descriptor;
            this.homeObject = homeObject;
        }

        @Override
        public DebuggableScript getDebuggableScript() {
            return descriptor;
        }
    }

    @Override
    public CompilationResult<JSScript> compileScript(
            CompilerEnvirons compilerEnv, ScriptNode tree, String rawSource) {
        CodeGenerator<JSScript> cgen = new CodeGenerator<>();
        JSDescriptor<JSScript> itsData = cgen.compile(compilerEnv, tree, rawSource, false);
        return new InterpreterCompilationResult<>(itsData, compilerEnv.homeObject());
    }

    @Override
    public CompilationResult<JSFunction> compileFunction(
            CompilerEnvirons compilerEnv, ScriptNode tree, String rawSource) {
        CodeGenerator<JSFunction> cgen = new CodeGenerator<>();
        JSDescriptor<JSFunction> itsData = cgen.compile(compilerEnv, tree, rawSource, true);
        return new InterpreterCompilationResult<>(itsData, compilerEnv.homeObject());
    }

    @Override
    public Script createScriptObject(
            CompilationResult<JSScript> compiled, Object staticSecurityDomain) {
        var result = (InterpreterCompilationResult<JSScript>) compiled;
        return JSFunction.createScript(result.descriptor, result.homeObject, staticSecurityDomain);
    }

    @Override
    public Function createFunctionObject(
            Context cx,
            VarScope scope,
            CompilationResult<JSFunction> compiled,
            Object staticSecurityDomain) {
        var result = (InterpreterCompilationResult<JSFunction>) compiled;
        return JSFunction.createFunction(
                cx, scope, result.descriptor, result.homeObject, staticSecurityDomain);
    }

    private static int getShort(byte[] iCode, int pc) {
        return (iCode[pc] << 8) | (iCode[pc + 1] & 0xFF);
    }

    private static int getIndex(byte[] iCode, int pc) {
        return ((iCode[pc] & 0xFF) << 8) | (iCode[pc + 1] & 0xFF);
    }

    private static int getInt(byte[] iCode, int pc) {
        return (iCode[pc] << 24)
                | ((iCode[pc + 1] & 0xFF) << 16)
                | ((iCode[pc + 2] & 0xFF) << 8)
                | (iCode[pc + 3] & 0xFF);
    }

    private static int getExceptionHandler(CallFrame frame, boolean onlyFinally) {
        int[] exceptionTable = frame.compilerData.exceptionTable;
        if (exceptionTable == null) {
            // No exception handlers
            return -1;
        }

        // Icode switch in the interpreter increments PC immediately
        // and it is necessary to subtract 1 from the saved PC
        // to point it before the start of the next instruction.
        int pc = frame.pc - 1;

        // OPT: use binary search
        int best = -1, bestStart = 0, bestEnd = 0;
        for (int i = 0; i != exceptionTable.length; i += EXCEPTION_SLOT_SIZE) {
            int start = exceptionTable[i + EXCEPTION_TRY_START_SLOT];
            int end = exceptionTable[i + EXCEPTION_TRY_END_SLOT];
            if (!(start <= pc && pc < end)) {
                continue;
            }
            if (onlyFinally && exceptionTable[i + EXCEPTION_TYPE_SLOT] != 1) {
                continue;
            }
            if (best >= 0) {
                // Since handlers always nest and they never have shared end
                // although they can share start  it is sufficient to compare
                // handlers ends
                if (bestEnd < end) {
                    continue;
                }
                // Check the above assumption
                if (bestStart > start) Kit.codeBug(); // should be nested
                if (bestEnd == end) Kit.codeBug(); // no ens sharing
            }
            best = i;
            bestStart = start;
            bestEnd = end;
        }
        return best;
    }

    static PrintStream interpreterBytecodePrintStream = System.out;

    static <T extends ScriptOrFn<T>> void dumpICode(
            InterpreterData.Builder<T> compilerData, JSDescriptor.Builder<T> desc) {
        if (!Token.printICode) {
            return;
        }

        byte[] iCode = compilerData.itsICode;
        int iCodeLength = iCode.length;
        PrintStream out = interpreterBytecodePrintStream;
        out.println("ICode dump, for " + desc.name + ", length = " + iCodeLength);
        out.println("MaxStack = " + compilerData.maxStack);

        ICodeDumpContext ctx = new ICodeDumpContext(out, compilerData);

        for (int pc = 0; pc < iCodeLength; ) {
            out.flush();
            out.print(" [" + pc + "] ");
            int token = iCode[pc];
            int icodeLength = bytecodeSpan(token);
            String tname = Icode.bytecodeName(token);
            ctx.pc = pc + 1;
            InstructionClass instr = instructionObjs[-Icode.MIN_ICODE + token];
            instr.dumpICode(token, tname, ctx);
            if (pc + icodeLength != ctx.pc) Kit.codeBug();
            pc += icodeLength;
        }

        int[] table = compilerData.exceptionTable;
        if (table != null) {
            out.println("Exception handlers: " + table.length / EXCEPTION_SLOT_SIZE);
            for (int i = 0; i != table.length; i += EXCEPTION_SLOT_SIZE) {
                int tryStart = table[i + EXCEPTION_TRY_START_SLOT];
                int tryEnd = table[i + EXCEPTION_TRY_END_SLOT];
                int handlerStart = table[i + EXCEPTION_HANDLER_SLOT];
                int type = table[i + EXCEPTION_TYPE_SLOT];
                int exceptionLocal = table[i + EXCEPTION_LOCAL_SLOT];

                out.println(
                        " tryStart="
                                + tryStart
                                + " tryEnd="
                                + tryEnd
                                + " handlerStart="
                                + handlerStart
                                + " type="
                                + (type == 0 ? "catch" : "finally")
                                + " exceptionLocal="
                                + exceptionLocal);
            }
        }
        out.flush();
    }

    private static int bytecodeSpan(int bytecode) {
        switch (bytecode) {
            case Token.THROW:
            case Token.YIELD:
            case Icode.YIELD_STAR:
            case Icode.GENERATOR:
            case Icode.GENERATOR_END:
            case Icode.GENERATOR_RETURN:
                // source line
                return 1 + 2;

            case Icode.GOSUB:
            case Token.GOTO:
            case Token.IFEQ:
            case Token.IFNE:
            case Icode.IFEQ_POP:
            case Icode.IF_NULL_UNDEF:
            case Icode.IF_NOT_NULL_UNDEF:
            case Icode.LEAVEDQ:
                // target pc offset
                return 1 + 2;

            case Icode.CALLSPECIAL:
            case Icode.CALLSPECIAL_OPTIONAL:
                // call type
                // is new
                // line number
                return 1 + 1 + 1 + 2;

            case Token.CATCH_SCOPE:
                // scope flag
                return 1 + 1;

            case Icode.VAR_INC_DEC:
            case Icode.NAME_INC_DEC:
            case Icode.PROP_INC_DEC:
            case Icode.ELEM_INC_DEC:
            case Icode.REF_INC_DEC:
                // type of ++/--
                return 1 + 1;

            case Icode.SHORTNUMBER:
                // short number
                return 1 + 2;

            case Icode.INTNUMBER:
                // int number
                return 1 + 4;

            case Icode.REG_IND1:
                // ubyte index
                return 1 + 1;

            case Icode.REG_IND2:
                // ushort index
                return 1 + 2;

            case Icode.REG_IND4:
                // int index
                return 1 + 4;

            case Icode.REG_STR1:
                // ubyte string index
                return 1 + 1;

            case Icode.REG_STR2:
                // ushort string index
                return 1 + 2;

            case Icode.REG_STR4:
                // int string index
                return 1 + 4;

            case Icode.GETVAR1:
            case Icode.SETVAR1:
            case Icode.SETCONSTVAR1:
                // byte var index
                return 1 + 1;

            case Icode.LINE:
                // line number
                return 1 + 2;

            case Icode.LITERAL_NEW_OBJECT:
                // make a copy or not flag
                return 1 + 1;

            case Icode.LITERAL_NEW_ARRAY:
                // skip indexes ID (uint16)
                return 1 + 2;

            case Icode.SPREAD:
                // 2-byte source position operand (always emitted, even when unused)
                return 1 + 2;

            case Icode.REG_BIGINT1:
                // ubyte bigint index
                return 1 + 1;

            case Icode.REG_BIGINT2:
                // ushort bigint index
                return 1 + 2;

            case Icode.REG_BIGINT4:
                // uint bigint index
                return 1 + 4;

            case Icode.OBJECT_REST:
                // computedKeyCount byte
                return 1 + 1;
        }
        if (!Icode.validBytecode(bytecode)) throw Kit.codeBug();
        return 1;
    }

    static int[] getLineNumbers(JSDescriptor desc) {
        JSCode code = desc.getCode();
        InterpreterData data;
        if (code instanceof InterpreterData) {
            data = (InterpreterData) code;
        } else {
            code = desc.getConstructor();
            if (code instanceof InterpreterData) {
                data = (InterpreterData) code;
            } else {
                Kit.codeBug("Attempt to get line number data for non-interpreted code.");
                return null;
            }
        }

        HashSet<Integer> presentLines = new HashSet<>();

        byte[] iCode = data.itsICode;
        int iCodeLength = iCode.length;
        for (int pc = 0; pc != iCodeLength; ) {
            int bytecode = iCode[pc];
            int span = bytecodeSpan(bytecode);
            if (bytecode == Icode.LINE) {
                if (span != 3) Kit.codeBug();
                int line = getIndex(iCode, pc + 1);
                presentLines.add(line);
            }
            pc += span;
        }

        int[] ret = new int[presentLines.size()];
        int i = 0;
        for (int num : presentLines) {
            ret[i++] = num;
        }
        return ret;
    }

    static String getRawSource(JSDescriptor<?> desc) {
        if (desc.getRawSource() == null) {
            return null;
        }
        return desc.getRawSource();
    }

    static void initFunction(Context cx, VarScope scope, JSDescriptor<?> parent, int index) {
        JSFunction fn;
        fn = JSFunction.createFunction(cx, scope, parent, index, null);
        var desc = fn.getDescriptor();
        ScriptRuntime.initFunction(cx, scope, fn, desc.getFunctionType(), parent.isEvalFunction());
    }

    static <T extends ScriptOrFn<T>> Object interpret(
            ScriptOrFn<T> ifun,
            InterpreterData<T> compilerData,
            Context cx,
            VarScope scope,
            Scriptable thisObj,
            Object[] args) {
        if (!ScriptRuntime.hasTopCall(cx)) Kit.codeBug();

        var desc = ifun.getDescriptor();

        if (cx.interpreterSecurityDomain != desc.getSecurityDomain()) {
            Object savedDomain = cx.interpreterSecurityDomain;
            cx.interpreterSecurityDomain = desc.getSecurityDomain();
            try {
                if (ifun instanceof JSScript) {
                    return desc.getSecurityController()
                            .callWithDomain(
                                    desc.getSecurityDomain(),
                                    cx,
                                    (JSScript) ifun,
                                    scope,
                                    thisObj,
                                    args);
                } else if (ifun instanceof JSFunction) {
                    return desc.getSecurityController()
                            .callWithDomain(
                                    desc.getSecurityDomain(),
                                    cx,
                                    (JSFunction) ifun,
                                    scope,
                                    thisObj,
                                    args);
                } else {
                    Kit.codeBug("Unknown compiled code type.");
                }
            } finally {
                cx.interpreterSecurityDomain = savedDomain;
            }
        }

        CallFrame frame =
                initFrame(
                        cx,
                        scope,
                        thisObj,
                        ifun.getHomeObject(),
                        args,
                        null,
                        null,
                        0,
                        args.length,
                        ifun,
                        compilerData,
                        null);
        frame.isContinuationsTopFrame = cx.isContinuationsTopCall;
        cx.isContinuationsTopCall = false;

        return interpretLoop(cx, frame, null);
    }

    static class GeneratorState {
        GeneratorState(int operation, Object value) {
            this.operation = operation;
            this.value = value;
        }

        int operation;
        Object value;
        RuntimeException returnedException;
    }

    public static Object resumeGenerator(
            Context cx, VarScope scope, int operation, Object savedState, Object value) {
        CallFrame frame = (CallFrame) savedState;
        CallFrame activeFrame = frame.shallowCloneFrozen(cx.lastInterpreterFrame);
        try {
            GeneratorState generatorState = new GeneratorState(operation, value);
            if (operation == NativeGenerator.GENERATOR_CLOSE) {
                try {
                    return interpretLoop(cx, activeFrame, generatorState);
                } catch (NativeGenerator.GeneratorClosedException e) {
                    // Re-throw GeneratorClosedException so ES6Generator can catch and complete
                    throw e;
                } catch (RuntimeException e) {
                    // Only propagate exceptions other than closingException
                    if (e != value) throw e;
                }
                return Undefined.instance;
            }
            Object result = interpretLoop(cx, activeFrame, generatorState);
            if (generatorState.returnedException != null) throw generatorState.returnedException;
            return result;
        } finally {
            activeFrame.syncStateToFrame(frame);
        }
    }

    public static Object restartContinuation(
            NativeContinuation c, Context cx, VarScope scope, Object[] args) {
        if (!ScriptRuntime.hasTopCall(cx)) {
            return ScriptRuntime.doTopCall(c, cx, scope, null, args, cx.isStrictMode());
        }

        Object arg;
        if (args.length == 0) {
            arg = Undefined.instance;
        } else {
            arg = args[0];
        }

        CallFrame capturedFrame = (CallFrame) c.getImplementation();
        if (capturedFrame == null) {
            // No frames to restart
            return arg;
        }

        var cjump = new ContinuationJump<CallFrame, InterpreterData<?>>(c, null);

        cjump.result = arg;
        return interpretLoop(cx, null, cjump);
    }

    // arbitrary number to add to instructionCount when calling
    // other functions
    private static final int INVOCATION_COST = 100;
    // arbitrary exception cost for instruction counting
    private static final int EXCEPTION_COST = 100;

    private static final Object undefined = Undefined.instance;

    private static class NewState {}

    private abstract static class InterpreterResult extends NewState {}

    private static class YieldResult extends InterpreterResult {
        private final Object yielding;

        private YieldResult(Object yielding) {
            this.yielding = yielding;
        }
    }

    private static class StateBreakResult extends InterpreterResult {
        private final CallFrame frame;

        private StateBreakResult(CallFrame frame) {
            this.frame = frame;
        }
    }

    private static class StateContinueResult extends InterpreterResult {
        private final CallFrame frame;
        private final int indexReg;

        private StateContinueResult(CallFrame frame, int indexReg) {
            this.frame = frame;
            this.indexReg = indexReg;
        }
    }

    private static class ThrowableResult extends InterpreterResult {
        private final CallFrame frame;
        private final Object throwable;

        private ThrowableResult(CallFrame frame, Object throwable) {
            this.frame = frame;
            this.throwable = throwable;
        }
    }

    private static final NewState BREAK_LOOP = new NewState() {};

    private static final NewState BREAK_JUMPLESSRUN = new NewState() {};

    private static final NewState BREAK_WITHOUT_EXTENSION = new NewState() {};

    private static class InterpreterState {
        int indexReg;
        BigInteger bigIntReg;
        String stringReg;
        final boolean instructionCounting;
        GeneratorState generatorState;
        Object throwable;

        InterpreterState(int indexReg, boolean instructionCounting) {
            this.indexReg = indexReg;
            this.instructionCounting = instructionCounting;
        }
    }

    private static class ICodeDumpContext {
        final PrintStream out;
        final InterpreterData.Builder<?> compilerData;

        int pc;
        int indexReg;

        ICodeDumpContext(PrintStream out, InterpreterData.Builder<?> compilerData) {
            this.out = out;
            this.compilerData = compilerData;
        }

        int getShort(int pc) {
            return Interpreter.getShort(compilerData.itsICode, pc);
        }

        int getIndex(int pc) {
            return Interpreter.getIndex(compilerData.itsICode, pc);
        }

        int getInt(int pc) {
            return Interpreter.getInt(compilerData.itsICode, pc);
        }
    }

    private abstract static class InstructionClass {
        abstract NewState execute(Context cx, CallFrame frame, InterpreterState state, int op);

        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.out.println(tname);
        }

        static void dumpJumpTarget(String tname, ICodeDumpContext ctx) {
            int newPC = ctx.pc + ctx.getShort(ctx.pc) - 1;
            ctx.out.println(tname + " " + newPC);
            ctx.pc += 2;
        }
    }

    private static final InstructionClass[] instructionObjs;

    static {
        instructionObjs = new InstructionClass[Token.LAST_BYTECODE_TOKEN + 1 - Icode.MIN_ICODE];
        int base = -Icode.MIN_ICODE;
        instructionObjs[base + Icode.GENERATOR] = new DoGenerator();
        instructionObjs[base + Token.YIELD] = new DoYield();
        instructionObjs[base + Icode.YIELD_STAR] = new DoYield();
        instructionObjs[base + Icode.GENERATOR_END] = new DoGeneratorEnd();
        instructionObjs[base + Icode.GENERATOR_RETURN] = new DoGeneratorReturn();
        instructionObjs[base + Token.THROW] = new DoThrow();
        instructionObjs[base + Token.RETHROW] = new DoRethrow();
        instructionObjs[base + Token.GE] = new DoCompare();
        instructionObjs[base + Token.LE] = new DoCompare();
        instructionObjs[base + Token.GT] = new DoCompare();
        instructionObjs[base + Token.LT] = new DoCompare();
        instructionObjs[base + Token.IN] = new DoInOrInstanceof();
        instructionObjs[base + Token.INSTANCEOF] = new DoInOrInstanceof();
        instructionObjs[base + Token.EQ] = new DoEquals();
        instructionObjs[base + Token.NE] = new DoNotEquals();
        instructionObjs[base + Token.SHEQ] = new DoShallowEquals();
        instructionObjs[base + Token.SHNE] = new DoShallowNotEquals();
        instructionObjs[base + Token.IFNE] = new DoIfNE();
        instructionObjs[base + Token.IFEQ] = new DoIfEQ();
        instructionObjs[base + Icode.IFEQ_POP] = new DoIfEQPop();
        instructionObjs[base + Icode.IF_NULL_UNDEF] = new DoIfNullUndef();
        instructionObjs[base + Icode.IF_NOT_NULL_UNDEF] = new DoIfNotNullUndef();
        instructionObjs[base + Token.GOTO] = new DoGoto();
        instructionObjs[base + Icode.GOSUB] = new DoGosub();
        instructionObjs[base + Icode.STARTSUB] = new DoStartSub();
        instructionObjs[base + Icode.RETSUB] = new DoRetsub();
        instructionObjs[base + Icode.POP] = new DoPop();
        instructionObjs[base + Icode.POP_RESULT] = new DoPopResult();
        instructionObjs[base + Icode.DUP] = new DoDup();
        instructionObjs[base + Icode.DUP2] = new DoDup2();
        instructionObjs[base + Icode.SWAP] = new DoSwap();
        instructionObjs[base + Token.RETURN] = new DoReturn();
        instructionObjs[base + Token.RETURN_RESULT] = new DoReturnResult();
        instructionObjs[base + Icode.RETUNDEF] = new DoReturnUndef();
        instructionObjs[base + Token.BITNOT] = new DoBitNot();
        instructionObjs[base + Token.BITAND] = new DoBitOp();
        instructionObjs[base + Token.BITOR] = new DoBitOp();
        instructionObjs[base + Token.BITXOR] = new DoBitOp();
        instructionObjs[base + Token.LSH] = new DoBitOp();
        instructionObjs[base + Token.RSH] = new DoBitOp();
        instructionObjs[base + Token.URSH] = new DoUnsignedRightShift();
        instructionObjs[base + Token.POS] = new DoPositive();
        instructionObjs[base + Token.NEG] = new DoNegative();
        instructionObjs[base + Token.ADD] = new DoAdd();
        instructionObjs[base + Token.SUB] = new DoArithmetic();
        instructionObjs[base + Token.MUL] = new DoArithmetic();
        instructionObjs[base + Token.DIV] = new DoArithmetic();
        instructionObjs[base + Token.MOD] = new DoArithmetic();
        instructionObjs[base + Token.EXP] = new DoArithmetic();
        instructionObjs[base + Token.NOT] = new DoNot();
        instructionObjs[base + Token.BINDNAME] = new DoBindName();
        instructionObjs[base + Token.STRICT_SETNAME] = new DoSetName();
        instructionObjs[base + Token.STRING_CONCAT] = new DoStringConcat();
        instructionObjs[base + Token.SETNAME] = new DoSetName();
        instructionObjs[base + Icode.SETCONST] = new DoSetConst();
        instructionObjs[base + Token.DELPROP] = new DoDelName();
        instructionObjs[base + Icode.DELNAME] = new DoDelName();
        instructionObjs[base + Icode.DELPROP_SUPER] = new DoDelPropSuper();
        instructionObjs[base + Token.GETPROPNOWARN] = new DoGetPropNoWarn();
        instructionObjs[base + Token.GETPROP] = new DoGetProp();
        instructionObjs[base + Token.GETPROP_SUPER] = new DoGetPropSuper();
        instructionObjs[base + Token.GETPROPNOWARN_SUPER] = new DoGetPropSuper();
        instructionObjs[base + Token.SETPROP] = new DoSetProp();
        instructionObjs[base + Token.SETPROP_SUPER] = new DoSetPropSuper();
        instructionObjs[base + Icode.PROP_INC_DEC] = new DoPropIncDec();
        instructionObjs[base + Token.GETELEM] = new DoGetElem();
        instructionObjs[base + Token.GETELEM_SUPER] = new DoGetElemSuper();
        instructionObjs[base + Token.SETELEM] = new DoSetElem();
        instructionObjs[base + Token.SETELEM_SUPER] = new DoSetElemSuper();
        instructionObjs[base + Icode.ELEM_INC_DEC] = new DoElemIncDec();
        instructionObjs[base + Token.GET_REF] = new DoGetRef();
        instructionObjs[base + Token.SET_REF] = new DoSetRef();
        instructionObjs[base + Token.DEL_REF] = new DoDelRef();
        instructionObjs[base + Icode.REF_INC_DEC] = new DoRefIncDec();
        instructionObjs[base + Token.LOCAL_LOAD] = new DoLocalLoad();
        instructionObjs[base + Icode.LOCAL_CLEAR] = new DoLocalClear();
        instructionObjs[base + Icode.NAME_AND_THIS] = new DoNameAndThis();
        instructionObjs[base + Icode.NAME_AND_THIS_OPTIONAL] = new DoNameAndThisOptional();
        instructionObjs[base + Icode.PROP_AND_THIS] = new DoPropAndThis();
        instructionObjs[base + Icode.PROP_AND_THIS_OPTIONAL] = new DoPropAndThisOptional();
        instructionObjs[base + Icode.ELEM_AND_THIS] = new DoElemAndThis();
        instructionObjs[base + Icode.ELEM_AND_THIS_OPTIONAL] = new DoElemAndThisOptional();
        instructionObjs[base + Icode.VALUE_AND_THIS] = new DoValueAndThis();
        instructionObjs[base + Icode.VALUE_AND_THIS_OPTIONAL] = new DoValueAndThisOptional();
        instructionObjs[base + Icode.CALLSPECIAL] = new DoCallSpecial();
        instructionObjs[base + Icode.CALLSPECIAL_OPTIONAL] = new DoCallSpecial();
        instructionObjs[base + Token.CALL] = new DoCallByteCode();
        instructionObjs[base + Icode.CALL_ON_SUPER] = new DoCallByteCode();
        instructionObjs[base + Icode.TAIL_CALL] = new DoCallByteCode();
        instructionObjs[base + Token.REF_CALL] = new DoCallByteCode();
        instructionObjs[base + Token.NEW] = new DoNew();
        instructionObjs[base + Token.TYPEOF] = new DoTypeOf();
        instructionObjs[base + Icode.TYPEOFNAME] = new DoTypeOfName();
        instructionObjs[base + Token.STRING] = new DoString();
        instructionObjs[base + Icode.SHORTNUMBER] = new DoShortNumber();
        instructionObjs[base + Icode.INTNUMBER] = new DoIntNumber();
        instructionObjs[base + Token.NUMBER] = new DoNumber();
        instructionObjs[base + Token.BIGINT] = new DoBigInt();
        instructionObjs[base + Token.NAME] = new DoName();
        instructionObjs[base + Icode.NAME_INC_DEC] = new DoNameIncDec();
        instructionObjs[base + Icode.SETCONSTVAR1] = new DoSetConstVar1();
        instructionObjs[base + Icode.SETCONSTVAR] = new DoSetConstVar();
        instructionObjs[base + Icode.SETVAR1] = new DoSetVar1();
        instructionObjs[base + Token.SETVAR] = new DoSetVar();
        instructionObjs[base + Icode.GETVAR1] = new DoGetVar1();
        instructionObjs[base + Token.GETVAR] = new DoGetVar();
        instructionObjs[base + Icode.VAR_INC_DEC] = new DoVarIncDec();
        instructionObjs[base + Icode.ZERO] = new DoZero();
        instructionObjs[base + Icode.ONE] = new DoOne();
        instructionObjs[base + Token.NULL] = new DoNull();
        instructionObjs[base + Token.THIS] = new DoThis();
        instructionObjs[base + Token.SUPER] = new DoSuper();
        instructionObjs[base + Token.THISFN] = new DoThisFunction();
        instructionObjs[base + Token.FALSE] = new DoFalse();
        instructionObjs[base + Token.TRUE] = new DoTrue();
        instructionObjs[base + Icode.UNDEF] = new DoUndef();
        instructionObjs[base + Token.ENTERWITH] = new DoEnterWith();
        instructionObjs[base + Token.LEAVEWITH] = new DoLeaveWith();
        instructionObjs[base + Token.CATCH_SCOPE] = new DoCatchScope();
        instructionObjs[base + Token.ENUM_INIT_KEYS] = new DoEnumInit();
        instructionObjs[base + Token.ENUM_INIT_VALUES] = new DoEnumInit();
        instructionObjs[base + Token.ENUM_INIT_ARRAY] = new DoEnumInit();
        instructionObjs[base + Token.ENUM_INIT_VALUES_IN_ORDER] = new DoEnumInit();
        instructionObjs[base + Token.ENUM_INIT_VALUES_IN_ORDER] = new DoEnumInit();
        instructionObjs[base + Token.ENUM_NEXT] = new DoEnumOp();
        instructionObjs[base + Token.ENUM_ID] = new DoEnumOp();
        instructionObjs[base + Token.REF_SPECIAL] = new DoRefSpecial();
        instructionObjs[base + Token.REF_MEMBER] = new DoRefMember();
        instructionObjs[base + Token.REF_NS_MEMBER] = new DoRefNsMember();
        instructionObjs[base + Token.REF_NAME] = new DoRefName();
        instructionObjs[base + Token.REF_NS_NAME] = new DoRefNsName();
        instructionObjs[base + Icode.SCOPE_LOAD] = new DoScopeLoad();
        instructionObjs[base + Icode.SCOPE_SAVE] = new DoScopeSave();
        instructionObjs[base + Icode.SPREAD] = new DoSpread();
        instructionObjs[base + Icode.OBJECT_REST] = new DoObjectRest();
        instructionObjs[base + Icode.CLOSURE_EXPR] = new DoClosureExpr();
        instructionObjs[base + Icode.METHOD_EXPR] = new DoMethodExpr();
        instructionObjs[base + Icode.CLOSURE_STMT] = new DoClosureStatement();
        instructionObjs[base + Token.REGEXP] = new DoRegExp();
        instructionObjs[base + Icode.TEMPLATE_LITERAL_CALLSITE] = new DoTemplateLiteralCallSite();
        instructionObjs[base + Icode.LITERAL_NEW_OBJECT] = new DoLiteralNewObject();
        instructionObjs[base + Icode.LITERAL_NEW_ARRAY] = new DoLiteralNewArray();
        instructionObjs[base + Icode.LITERAL_SET] = new DoLiteralSet();
        instructionObjs[base + Icode.LITERAL_GETTER] = new DoLiteralGetter();
        instructionObjs[base + Icode.LITERAL_SETTER] = new DoLiteralSetter();
        instructionObjs[base + Icode.LITERAL_KEY_SET] = new DoLiteralKeySet();
        instructionObjs[base + Token.OBJECTLIT] = new DoObjectLit();
        instructionObjs[base + Token.ARRAYLIT] = new DoArrayLiteral();
        instructionObjs[base + Icode.SPARE_ARRAYLIT] = new DoArrayLiteral();
        instructionObjs[base + Icode.ENTERDQ] = new DoEnterDotQuery();
        instructionObjs[base + Icode.LEAVEDQ] = new DoLeaveDotQuery();
        instructionObjs[base + Token.DEFAULTNAMESPACE] = new DoDefaultNamespace();
        instructionObjs[base + Token.ESCXMLATTR] = new DoEscXMLAttr();
        instructionObjs[base + Token.ESCXMLTEXT] = new DoEscXMLText();
        instructionObjs[base + Icode.DEBUGGER] = new DoDebug();
        instructionObjs[base + Icode.LINE] = new DoLineChange();
        instructionObjs[base + Icode.REG_IND_C0] = new DoIndexCn();
        instructionObjs[base + Icode.REG_IND_C1] = new DoIndexCn();
        instructionObjs[base + Icode.REG_IND_C2] = new DoIndexCn();
        instructionObjs[base + Icode.REG_IND_C3] = new DoIndexCn();
        instructionObjs[base + Icode.REG_IND_C4] = new DoIndexCn();
        instructionObjs[base + Icode.REG_IND_C5] = new DoIndexCn();
        instructionObjs[base + Icode.REG_IND1] = new DoRegIndex1();
        instructionObjs[base + Icode.REG_IND2] = new DoRegIndex2();
        instructionObjs[base + Icode.REG_IND4] = new DoRegIndex4();
        instructionObjs[base + Icode.REG_STR_C0] = new DoStringCn();
        instructionObjs[base + Icode.REG_STR_C1] = new DoStringCn();
        instructionObjs[base + Icode.REG_STR_C2] = new DoStringCn();
        instructionObjs[base + Icode.REG_STR_C3] = new DoStringCn();
        instructionObjs[base + Icode.REG_STR1] = new DoRegString1();
        instructionObjs[base + Icode.REG_STR2] = new DoRegString2();
        instructionObjs[base + Icode.REG_STR4] = new DoRegString4();
        instructionObjs[base + Icode.REG_BIGINT_C0] = new DoBigIntCn();
        instructionObjs[base + Icode.REG_BIGINT_C1] = new DoBigIntCn();
        instructionObjs[base + Icode.REG_BIGINT_C2] = new DoBigIntCn();
        instructionObjs[base + Icode.REG_BIGINT_C3] = new DoBigIntCn();
        instructionObjs[base + Icode.REG_BIGINT1] = new DoRegBigInt1();
        instructionObjs[base + Icode.REG_BIGINT2] = new DoRegBigInt2();
        instructionObjs[base + Icode.REG_BIGINT4] = new DoRegBigInt4();
    }

    private static Object interpretLoop(Context cx, CallFrame frame, Object throwable) {
        var oldFrame = cx.lastInterpreterFrame;
        try {
            // throwable holds exception object to rethrow or catch
            // It is also used for continuation restart in which case
            // it holds ContinuationJump

            final boolean instructionCounting = cx.instructionThreshold != 0;

            String stringReg = null;
            BigInteger bigIntReg = null;
            int indexReg = -1;

            // When restarting continuation throwable is not null and to jump
            // to the code that rewind continuation state indexReg should be set
            // to -1.
            // With the normal call throwable == null and indexReg == -1 allows to
            // catch bugs with using indeReg to access array elements before
            // initializing indexReg.

            GeneratorState generatorState = null;
            if (throwable != null) {
                if (throwable instanceof GeneratorState) {
                    generatorState = (GeneratorState) throwable;

                    // reestablish this call frame
                    enterFrame(cx, frame, ScriptRuntime.emptyArgs, true);
                    throwable = null;
                } else if (!(throwable instanceof ContinuationJump)) {
                    // It should be continuation
                    Kit.codeBug();
                }
            }

            Object interpreterResult = null;
            double interpreterResultDbl = 0.0;

            StateLoop:
            for (; ; ) {

                Withoutexceptions:
                try {

                    if (throwable != null) {
                        // Need to return both 'frame' and 'throwable' from
                        // 'processThrowable', so just added a 'throwable'
                        // member in 'frame'.
                        frame =
                                processThrowable(
                                        cx, throwable, frame, indexReg, instructionCounting);
                        throwable = frame.throwable;
                        frame.throwable = null;
                    } else {
                        if (generatorState == null && frame.frozen) Kit.codeBug();
                    }

                    InterpreterResult result =
                            interpretFunction(
                                    cx,
                                    frame,
                                    throwable,
                                    generatorState,
                                    indexReg,
                                    instructionCounting);
                    if (result instanceof StateContinueResult) {
                        StateContinueResult scr = (StateContinueResult) result;
                        frame = scr.frame;
                        indexReg = scr.indexReg;
                        continue StateLoop;
                    } else if (result instanceof StateBreakResult) {
                        StateBreakResult sbr = (StateBreakResult) result;
                        frame = sbr.frame;
                        interpreterResult = frame.result;
                        interpreterResultDbl = frame.resultDbl;
                        break StateLoop;
                    } else if (result instanceof YieldResult) {
                        exitFrame(cx, frame, null);
                        return ((YieldResult) result).yielding;
                    } else if (result instanceof ThrowableResult) {
                        ThrowableResult tr = (ThrowableResult) result;
                        frame = tr.frame;
                        throwable = tr.throwable;
                        break Withoutexceptions;
                    } else {
                        Kit.codeBug();
                    }
                } // end of interpreter withoutExceptions: try
                catch (Throwable ex) {
                    if (throwable != null) {
                        // This is serious bug and it is better to track it ASAP
                        ex.printStackTrace(System.err);
                        throw new IllegalStateException();
                    }
                    throwable = ex;
                }

                // This should be reachable only after above catch or from
                // finally when it needs to propagate exception or from
                // explicit throw
                if (throwable == null) Kit.codeBug();

                // Exception type
                final int EX_CATCH_STATE = 2; // Can execute JS catch
                final int EX_FINALLY_STATE = 1; // Can execute JS finally
                final int EX_NO_JS_STATE = 0; // Terminate JS execution

                int exState;
                ContinuationJump cjump = null;

                if (generatorState != null
                        && generatorState.operation == NativeGenerator.GENERATOR_CLOSE
                        && throwable == generatorState.value) {
                    exState = EX_FINALLY_STATE;
                } else if (throwable instanceof JavaScriptException) {
                    exState = EX_CATCH_STATE;
                } else if (throwable instanceof EcmaError) {
                    // an offical ECMA error object,
                    exState = EX_CATCH_STATE;
                } else if (throwable instanceof EvaluatorException) {
                    exState = EX_CATCH_STATE;
                } else if (throwable instanceof ContinuationPending) {
                    exState = EX_NO_JS_STATE;
                } else if (throwable instanceof RuntimeException) {
                    exState =
                            cx.hasFeature(Context.FEATURE_ENHANCED_JAVA_ACCESS)
                                    ? EX_CATCH_STATE
                                    : EX_FINALLY_STATE;
                } else if (throwable instanceof Error) {
                    exState =
                            cx.hasFeature(Context.FEATURE_ENHANCED_JAVA_ACCESS)
                                    ? EX_CATCH_STATE
                                    : EX_NO_JS_STATE;
                } else if (throwable instanceof ContinuationJump) {
                    // It must be ContinuationJump
                    exState = EX_FINALLY_STATE;
                    cjump = (ContinuationJump) throwable;
                } else {
                    exState =
                            cx.hasFeature(Context.FEATURE_ENHANCED_JAVA_ACCESS)
                                    ? EX_CATCH_STATE
                                    : EX_FINALLY_STATE;
                }

                if (instructionCounting) {
                    try {
                        addInstructionCount(cx, frame, EXCEPTION_COST);
                    } catch (RuntimeException ex) {
                        throwable = ex;
                        exState = EX_FINALLY_STATE;
                    } catch (Error ex) {
                        // Error from instruction counting
                        //     => unconditionally terminate JS
                        throwable = ex;
                        cjump = null;
                        exState = EX_NO_JS_STATE;
                    }
                }
                if (frame.debuggerFrame != null && throwable instanceof RuntimeException) {
                    // Call debugger only for RuntimeException
                    RuntimeException rex = (RuntimeException) throwable;
                    try {
                        frame.debuggerFrame.onExceptionThrown(cx, rex);
                    } catch (Throwable ex) {
                        // Any exception from debugger
                        //     => unconditionally terminate JS
                        throwable = ex;
                        cjump = null;
                        exState = EX_NO_JS_STATE;
                    }
                }

                for (; ; ) {
                    if (exState != EX_NO_JS_STATE) {
                        boolean onlyFinally = (exState != EX_CATCH_STATE);
                        indexReg = getExceptionHandler(frame, onlyFinally);
                        if (indexReg >= 0) {
                            // We caught an exception, restart the loop
                            // with exception pending the processing at the loop
                            // start
                            continue StateLoop;
                        }
                    }
                    // No allowed exception handlers in this frame, unwind
                    // to parent and try to look there

                    exitFrame(cx, frame, throwable);

                    frame = frame.parentFrame;
                    if (frame == null) {
                        break;
                    }
                    if (cjump != null && Objects.equals(cjump.branchFrame, frame)) {
                        // Continuation branch point was hit,
                        // restart the state loop to reenter continuation
                        indexReg = -1;
                        continue StateLoop;
                    }
                }

                // No more frames, rethrow the exception or deal with continuation
                if (cjump != null) {
                    if (cjump.branchFrame != null) {
                        // The above loop should locate the top frame
                        Kit.codeBug();
                    }
                    if (cjump.capturedFrame != null) {
                        // Restarting detached continuation
                        indexReg = -1;
                        continue StateLoop;
                    }
                    // Return continuation result to the caller
                    interpreterResult = cjump.result;
                    interpreterResultDbl = cjump.resultDbl;
                    throwable = null;
                }
                break StateLoop;
            } // end of StateLoop: for(;;)

            // Do cleanups/restorations before the final return or throw

            if (frame != null) {
                cx.lastInterpreterFrame =
                        frame.parentFrame == null
                                ? frame.previousInterpreterFrame
                                : frame.parentFrame;
            } else {
                cx.lastInterpreterFrame = null;
            }

            if (throwable != null) {
                if (throwable instanceof RuntimeException) {
                    throw (RuntimeException) throwable;
                }
                // Must be instance of Error or code bug
                throw (Error) throwable;
            }

            return (interpreterResult != DBL_MRK)
                    ? interpreterResult
                    : ScriptRuntime.wrapNumber(interpreterResultDbl);
        } finally {
            cx.lastInterpreterFrame = oldFrame;
        }
    }

    private static final Object DBL_MRK = DOUBLE_MARK;

    private static InterpreterResult interpretFunction(
            Context cx,
            CallFrame frame,
            Object tble,
            GeneratorState genState,
            int iReg,
            boolean instructionCounting) {
        final InterpreterState state = new InterpreterState(iReg, instructionCounting);

        withoutExceptions:
        try {

            // Use local variables for constant values in frame
            // for faster access
            final byte[] iCode = ((InterpreterData) frame.compilerData).itsICode;

            state.generatorState = genState;
            state.throwable = tble;

            // Store new frame in cx which is used for error reporting etc.
            cx.lastInterpreterFrame = frame;

            Loop:
            for (; ; ) {

                NewState nextState;
                do {
                    // Exception handler assumes that PC is already incremented
                    // pass the instruction start when it searches the
                    // exception handler
                    int op = iCode[frame.pc++];

                    var insn = instructionObjs[-Icode.MIN_ICODE + op];

                    nextState = insn.execute(cx, frame, state, op);
                } while (nextState == null);

                if (nextState == BREAK_LOOP) {
                    break Loop;
                } else if (nextState == BREAK_JUMPLESSRUN) {
                    if (instructionCounting) {
                        addInstructionCount(cx, frame, 2);
                    }
                    int offset = getShort(iCode, frame.pc);
                    if (offset != 0) {
                        // -1 accounts for pc pointing to jump opcode + 1
                        frame.pc += offset - 1;
                    } else {
                        frame.pc = frame.compilerData.longJumps.get(frame.pc);
                    }
                    if (instructionCounting) {
                        frame.pcPrevBranch = frame.pc;
                    }
                } else if (nextState == BREAK_WITHOUT_EXTENSION) {
                    break withoutExceptions;
                } else {
                    return (InterpreterResult) nextState;
                }
            }

            exitFrame(cx, frame, null);
            if (frame.parentFrame != null) {
                CallFrame newFrame = frame.parentFrame;
                if (newFrame.frozen) {
                    newFrame = newFrame.cloneFrozen();
                }
                setCallResult(newFrame, frame.result, frame.resultDbl);
                return new StateContinueResult(newFrame, state.indexReg);
            }
            return new StateBreakResult(frame);

        } // end of interpreter withoutExceptions: try
        catch (Throwable ex) {
            if (state.throwable != null) {
                // This is serious bug and it is better to track it ASAP
                ex.printStackTrace(System.err);
                throw new IllegalStateException();
            }
            state.throwable = ex;
        }
        return new ThrowableResult(frame, state.throwable);
    }

    private static class DoGenerator extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            if (!frame.frozen) {
                // First time encountering this opcode: create new generator
                // object and return
                generatorCreate(cx, frame);
                return BREAK_LOOP;
            }
            /* This is both where we yield from and re-enter the
             * generator.
             */
            if (!frame.frozen) {
                return new YieldResult(
                        freezeGenerator(
                                cx, frame, state, state.generatorState, op == Icode.YIELD_STAR));
            }
            Object obj = thawGenerator(frame, state, state.generatorState, op);
            if (obj != Scriptable.NOT_FOUND) {
                state.throwable = obj;
                return BREAK_WITHOUT_EXTENSION;
            }
            return null;
        }

        private static void generatorCreate(Context cx, CallFrame frame) {
            // First time encountering this opcode: create new generator
            // object and return
            frame.pc--; // we want to come back here when we resume
            CallFrame generatorFrame = captureFrameForGenerator(frame);
            generatorFrame.frozen = true;
            if (cx.getLanguageVersion() >= Context.VERSION_ES6) {
                frame.result =
                        new ES6Generator(
                                frame.scope,
                                (JSFunction) generatorFrame.fnOrScript,
                                generatorFrame);
            } else {
                frame.result =
                        new NativeGenerator(
                                frame.scope,
                                (JSFunction) generatorFrame.fnOrScript,
                                generatorFrame);
            }
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            int line = ctx.getIndex(ctx.pc);
            ctx.out.println(tname + " : " + line);
            ctx.pc += 2;
        }
    }

    private static Object freezeGenerator(
            Context cx,
            CallFrame frame,
            InterpreterState state,
            GeneratorState generatorState,
            boolean yieldStar) {
        if (generatorState.operation == NativeGenerator.GENERATOR_CLOSE) {
            // Error: no yields when generator is closing
            throw ScriptRuntime.typeErrorById("msg.yield.closing");
        }
        // return to our caller (which should be a method of NativeGenerator)
        frame.frozen = true;
        frame.result = frame.stack[frame.stackTop];
        frame.resultDbl = frame.doubleStack[frame.stackTop];
        frame.pc--; // we want to come back here when we resume
        final Object result =
                (frame.result != DOUBLE_MARK)
                        ? frame.result
                        : ScriptRuntime.wrapNumber(frame.resultDbl);
        if (yieldStar) {
            return new ES6Generator.YieldStarResult(result);
        }
        return result;
    }

    private static Object thawGenerator(
            CallFrame frame, InterpreterState state, GeneratorState generatorState, int op) {
        // we are resuming execution
        frame.frozen = false;
        int sourceLine = getIndex(frame.compilerData.itsICode, frame.pc);
        frame.pc += 2; // skip line number data
        if (generatorState.operation == NativeGenerator.GENERATOR_THROW) {
            // processing a call to <generator>.throw(exception): must
            // act as if exception was thrown from resumption point.
            return new JavaScriptException(
                    generatorState.value,
                    frame.fnOrScript.getDescriptor().getSourceName(),
                    sourceLine);
        }
        if (generatorState.operation == NativeGenerator.GENERATOR_CLOSE) {
            return generatorState.value;
        }
        if (generatorState.operation != NativeGenerator.GENERATOR_SEND) throw Kit.codeBug();
        if ((op == Token.YIELD) || (op == Icode.YIELD_STAR)) {
            frame.stack[frame.stackTop] = generatorState.value;
        }
        return Scriptable.NOT_FOUND;
    }

    private static class DoYield extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            /* This is both where we yield from and re-enter the
             * generator.
             */
            if (!frame.frozen) {
                return new YieldResult(
                        freezeGenerator(
                                cx, frame, state, state.generatorState, op == Icode.YIELD_STAR));
            }
            Object obj = thawGenerator(frame, state, state.generatorState, op);
            if (obj != Scriptable.NOT_FOUND) {
                state.throwable = obj;
                return BREAK_WITHOUT_EXTENSION;
            }
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            int line = ctx.getIndex(ctx.pc);
            ctx.out.println(tname + " : " + line);
            ctx.pc += 2;
        }
    }

    private static class DoGeneratorEnd extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            // throw StopIteration
            frame.frozen = true;
            int sourceLine = getIndex(frame.compilerData.itsICode, frame.pc);
            state.generatorState.returnedException =
                    new JavaScriptException(
                            NativeIterator.getStopIterationObject(frame.scope),
                            frame.fnOrScript.getDescriptor().getSourceName(),
                            sourceLine);
            return BREAK_LOOP;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            int line = ctx.getIndex(ctx.pc);
            ctx.out.println(tname + " : " + line);
            ctx.pc += 2;
        }
    }

    private static class DoGeneratorReturn extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            // throw StopIteration with the value of "return"
            frame.frozen = true;
            frame.result = frame.stack[frame.stackTop];
            frame.resultDbl = frame.doubleStack[frame.stackTop--];

            NativeIterator.StopIteration si =
                    new NativeIterator.StopIteration(
                            (frame.result == DOUBLE_MARK)
                                    ? Double.valueOf(frame.resultDbl)
                                    : frame.result);

            int sourceLine = getIndex(frame.compilerData.itsICode, frame.pc);
            state.generatorState.returnedException =
                    new JavaScriptException(
                            si, frame.fnOrScript.getDescriptor().getSourceName(), sourceLine);
            return BREAK_LOOP;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            int line = ctx.getIndex(ctx.pc);
            ctx.out.println(tname + " : " + line);
            ctx.pc += 2;
        }
    }

    private static class DoRethrow extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.indexReg += frame.compilerData.maxVars;
            state.throwable = frame.stack[state.indexReg];
            return BREAK_WITHOUT_EXTENSION;
        }
    }

    private static class DoThrow extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.throwable =
                    throwObject(
                            frame,
                            frame.stack,
                            frame.doubleStack,
                            frame.compilerData,
                            frame.compilerData.itsICode,
                            state);
            --frame.stackTop;
            return BREAK_WITHOUT_EXTENSION;
        }

        private static Object throwObject(
                CallFrame frame,
                final Object[] stack,
                final double[] sDbl,
                final InterpreterData compilerData,
                final byte[] iCode,
                InterpreterState state) {
            Object throwable;
            Object value = stack[frame.stackTop];
            if (value == DOUBLE_MARK) value = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);

            int sourceLine = getIndex(iCode, frame.pc);
            throwable =
                    new JavaScriptException(
                            value, frame.fnOrScript.getDescriptor().getSourceName(), sourceLine);
            return throwable;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            int line = ctx.getIndex(ctx.pc);
            ctx.out.println(tname + " : " + line);
            ctx.pc += 2;
        }
    }

    private static class DoCompare extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object[] stack = frame.stack;
            double[] sDbl = frame.doubleStack;
            Object rhs = stack[frame.stackTop];
            Object lhs = stack[--frame.stackTop];
            boolean valBln;
            if (lhs == DOUBLE_MARK && rhs == DOUBLE_MARK) {
                valBln =
                        ScriptRuntime.compareTo(sDbl[frame.stackTop], sDbl[frame.stackTop + 1], op);
                stack[frame.stackTop] = valBln;
                return null;
            }
            object_compare:
            {
                number_compare:
                {
                    Number rNum, lNum;
                    if (rhs == DOUBLE_MARK) {
                        rNum = sDbl[frame.stackTop + 1];
                        lNum = stack_numeric(frame, frame.stackTop);
                    } else if (lhs == DOUBLE_MARK) {
                        rNum = ScriptRuntime.toNumeric(rhs);
                        lNum = sDbl[frame.stackTop];
                    } else {
                        break number_compare;
                    }
                    valBln = ScriptRuntime.compare(lNum, rNum, op);
                    break object_compare;
                }
                valBln = ScriptRuntime.compare(lhs, rhs, op);
            }
            stack[frame.stackTop] = valBln;
            return null;
        }
    }

    private static class DoInOrInstanceof extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object[] stack = frame.stack;
            double[] sDbl = frame.doubleStack;
            Object rhs = stack[frame.stackTop];
            if (rhs == DOUBLE_MARK) rhs = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            Object lhs = stack[--frame.stackTop];
            if (lhs == DOUBLE_MARK) lhs = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            boolean valBln;
            if (op == Token.IN) {
                valBln = ScriptRuntime.in(lhs, rhs, cx);
            } else {
                valBln = ScriptRuntime.instanceOf(lhs, rhs, cx);
            }
            stack[frame.stackTop] = valBln;
            return null;
        }
    }

    private static class DoEquals extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object[] stack = frame.stack;
            double[] sDbl = frame.doubleStack;
            final boolean res = doEquals(frame, stack, sDbl);
            stack[frame.stackTop] = res;
            return null;
        }
    }

    private static class DoNotEquals extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object[] stack = frame.stack;
            double[] sDbl = frame.doubleStack;
            final boolean res = doEquals(frame, stack, sDbl);
            stack[frame.stackTop] = !res;
            return null;
        }
    }

    private static boolean doEquals(CallFrame frame, Object[] stack, double[] sDbl) {
        final Object rhs = stack[frame.stackTop--];
        final Object lhs = stack[frame.stackTop];
        final boolean res;
        if (rhs == DOUBLE_MARK) {
            if (lhs == DOUBLE_MARK) {
                res = (sDbl[frame.stackTop] == sDbl[frame.stackTop + 1]);
            } else {
                res = ScriptRuntime.eqNumber(sDbl[frame.stackTop + 1], lhs);
            }
        } else if (lhs == DOUBLE_MARK) {
            res = ScriptRuntime.eqNumber(sDbl[frame.stackTop], rhs);
        } else {
            res = ScriptRuntime.eq(lhs, rhs);
        }
        return res;
    }

    private static class DoShallowEquals extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object[] stack = frame.stack;
            double[] sDbl = frame.doubleStack;
            final boolean res = doShallowEquals(frame, stack, sDbl);
            stack[frame.stackTop] = res;
            return null;
        }
    }

    private static class DoShallowNotEquals extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object[] stack = frame.stack;
            double[] sDbl = frame.doubleStack;
            final boolean res = doShallowEquals(frame, stack, sDbl);
            stack[frame.stackTop] = !res;
            return null;
        }
    }

    private static boolean doShallowEquals(CallFrame frame, Object[] stack, double[] sDbl) {
        final Object rhs = stack[frame.stackTop--];
        final Object lhs = stack[frame.stackTop];
        final boolean res;
        if (rhs == DOUBLE_MARK) {
            double rDbl = sDbl[frame.stackTop + 1];
            if (lhs == DOUBLE_MARK) {
                res = rDbl == sDbl[frame.stackTop];
            } else if (lhs instanceof Number && !(lhs instanceof BigInteger)) {
                res = rDbl == ((Number) lhs).doubleValue();
            } else {
                res = false;
            }
        } else if (lhs == DOUBLE_MARK) {
            double ldbl = sDbl[frame.stackTop];
            if (rhs instanceof Number && !(rhs instanceof BigInteger)) {
                res = ldbl == ((Number) rhs).doubleValue();
            } else {
                res = false;
            }
        } else {
            res = ScriptRuntime.shallowEq(lhs, rhs);
        }
        return res;
    }

    private static class DoIfNE extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            if (stack_boolean(frame, frame.stackTop--)) {
                frame.pc += 2;
                return null;
            }
            return BREAK_JUMPLESSRUN;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            dumpJumpTarget(tname, ctx);
        }
    }

    private static class DoIfEQ extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            if (!stack_boolean(frame, frame.stackTop--)) {
                frame.pc += 2;
                return null;
            }
            return BREAK_JUMPLESSRUN;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            dumpJumpTarget(tname, ctx);
        }
    }

    private static class DoIfEQPop extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            if (!stack_boolean(frame, frame.stackTop--)) {
                frame.pc += 2;
                return null;
            }
            frame.stack[frame.stackTop--] = null;
            return BREAK_JUMPLESSRUN;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            dumpJumpTarget(tname, ctx);
        }
    }

    private static class DoIfNullUndef extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object val = frame.stack[frame.stackTop];
            --frame.stackTop;
            if (val != null && !Undefined.isUndefined(val)) {
                frame.pc += 2;
                return null;
            }
            return BREAK_JUMPLESSRUN;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            dumpJumpTarget(tname, ctx);
        }
    }

    private static class DoIfNotNullUndef extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object val = frame.stack[frame.stackTop];
            --frame.stackTop;
            if (val == null || Undefined.isUndefined(val)) {
                frame.pc += 2;
                return null;
            }
            return BREAK_JUMPLESSRUN;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            dumpJumpTarget(tname, ctx);
        }
    }

    private static class DoGoto extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            return BREAK_JUMPLESSRUN;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            dumpJumpTarget(tname, ctx);
        }
    }

    private static class DoGosub extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            ++frame.stackTop;
            frame.stack[frame.stackTop] = DOUBLE_MARK;
            frame.doubleStack[frame.stackTop] = frame.pc + 2;
            return BREAK_JUMPLESSRUN;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            dumpJumpTarget(tname, ctx);
        }
    }

    private static class DoStartSub extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            final InterpreterData compilerData = frame.compilerData;
            if (frame.stackTop == frame.emptyStackTop + 1) {
                // Call from Icode.GOSUB: store return PC address in the local
                state.indexReg += compilerData.maxVars;
                stack[state.indexReg] = stack[frame.stackTop];
                sDbl[state.indexReg] = sDbl[frame.stackTop];
                --frame.stackTop;
            } else {
                // Call from exception handler: exception object is already
                // stored
                // in the local
                if (frame.stackTop != frame.emptyStackTop) Kit.codeBug();
            }
            return null;
        }
    }

    private static class DoRetsub extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            // state.indexReg: local to store return address
            if (state.instructionCounting) {
                addInstructionCount(cx, frame, 0);
            }
            state.indexReg += frame.compilerData.maxVars;
            Object value = frame.stack[state.indexReg];
            if (value != DOUBLE_MARK) {
                // Invocation from exception handler, restore object to
                // rethrow
                state.throwable = value;
                return BREAK_WITHOUT_EXTENSION;
            }
            // Normal return from GOSUB
            frame.pc = (int) frame.doubleStack[state.indexReg];
            if (state.instructionCounting) {
                frame.pcPrevBranch = frame.pc;
            }
            return null;
        }
    }

    private static class DoPop extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            stack[frame.stackTop] = null;
            frame.stackTop--;
            return null;
        }
    }

    private static class DoPopResult extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            frame.result = stack[frame.stackTop];
            frame.resultDbl = sDbl[frame.stackTop];
            stack[frame.stackTop] = null;
            --frame.stackTop;
            return null;
        }
    }

    private static class DoDup extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            stack[frame.stackTop + 1] = stack[frame.stackTop];
            sDbl[frame.stackTop + 1] = sDbl[frame.stackTop];
            frame.stackTop++;
            return null;
        }
    }

    private static class DoDup2 extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            stack[frame.stackTop + 1] = stack[frame.stackTop - 1];
            sDbl[frame.stackTop + 1] = sDbl[frame.stackTop - 1];
            stack[frame.stackTop + 2] = stack[frame.stackTop];
            sDbl[frame.stackTop + 2] = sDbl[frame.stackTop];
            frame.stackTop += 2;
            return null;
        }
    }

    private static class DoSwap extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Object o = stack[frame.stackTop];
            stack[frame.stackTop] = stack[frame.stackTop - 1];
            stack[frame.stackTop - 1] = o;
            double d = sDbl[frame.stackTop];
            sDbl[frame.stackTop] = sDbl[frame.stackTop - 1];
            sDbl[frame.stackTop - 1] = d;
            return null;
        }
    }

    private static class DoReturn extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            frame.result = stack[frame.stackTop];
            frame.resultDbl = sDbl[frame.stackTop];
            --frame.stackTop;
            return BREAK_LOOP;
        }
    }

    private static class DoReturnResult extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            return BREAK_LOOP;
        }
    }

    private static class DoReturnUndef extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            frame.result = undefined;
            return BREAK_LOOP;
        }
    }

    private static class DoBitNot extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object[] stack = frame.stack;
            double[] sDbl = frame.doubleStack;
            Number value = stack_numeric(frame, frame.stackTop);
            Number result = ScriptRuntime.bitwiseNOT(value);
            if (result instanceof BigInteger) {
                stack[frame.stackTop] = result;
            } else {
                stack[frame.stackTop] = DOUBLE_MARK;
                sDbl[frame.stackTop] = result.doubleValue();
            }
            return null;
        }
    }

    private static class DoBitOp extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object[] stack = frame.stack;
            double[] sDbl = frame.doubleStack;
            if (stack[frame.stackTop] == DOUBLE_MARK && stack[frame.stackTop - 1] == DOUBLE_MARK) {
                doFastBitOp(cx, frame, state, op);
                return null;
            }
            Number lValue = stack_numeric(frame, frame.stackTop - 1);
            Number rValue = stack_numeric(frame, frame.stackTop);
            frame.stackTop--;

            Number result = null;
            switch (op) {
                case Token.BITAND:
                    result = ScriptRuntime.bitwiseAND(lValue, rValue);
                    break;
                case Token.BITOR:
                    result = ScriptRuntime.bitwiseOR(lValue, rValue);
                    break;
                case Token.BITXOR:
                    result = ScriptRuntime.bitwiseXOR(lValue, rValue);
                    break;
                case Token.LSH:
                    result = ScriptRuntime.leftShift(lValue, rValue);
                    break;
                case Token.RSH:
                    result = ScriptRuntime.signedRightShift(lValue, rValue);
                    break;
            }

            if (result instanceof BigInteger) {
                stack[frame.stackTop] = result;
            } else {
                stack[frame.stackTop] = DOUBLE_MARK;
                sDbl[frame.stackTop] = result.doubleValue();
            }
            return null;
        }

        private static NewState doFastBitOp(
                Context cx, CallFrame frame, InterpreterState state, int op) {
            Object[] stack = frame.stack;
            double[] sDbl = frame.doubleStack;
            double lValue = sDbl[frame.stackTop - 1];
            double rValue = sDbl[frame.stackTop];
            frame.stackTop--;

            double result = 0.0;
            switch (op) {
                case Token.BITAND:
                    result = ScriptRuntime.bitwiseAND(lValue, rValue);
                    break;
                case Token.BITOR:
                    result = ScriptRuntime.bitwiseOR(lValue, rValue);
                    break;
                case Token.BITXOR:
                    result = ScriptRuntime.bitwiseXOR(lValue, rValue);
                    break;
                case Token.LSH:
                    result = ScriptRuntime.leftShift(lValue, rValue);
                    break;
                case Token.RSH:
                    result = ScriptRuntime.signedRightShift(lValue, rValue);
                    break;
            }

            stack[frame.stackTop] = DOUBLE_MARK;
            sDbl[frame.stackTop] = result;
            return null;
        }
    }

    private static class DoUnsignedRightShift extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            double lDbl = stack_double(frame, frame.stackTop - 1);
            int rIntValue = stack_int32(frame, frame.stackTop) & 0x1F;
            stack[--frame.stackTop] = DOUBLE_MARK;
            sDbl[frame.stackTop] = ScriptRuntime.toUint32(lDbl) >>> rIntValue;
            return null;
        }
    }

    private static class DoPositive extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            double rDbl = stack_double(frame, frame.stackTop);
            stack[frame.stackTop] = DOUBLE_MARK;
            sDbl[frame.stackTop] = rDbl;
            return null;
        }
    }

    private static class DoNegative extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Number rNum = stack_numeric(frame, frame.stackTop);
            Number rNegNum = ScriptRuntime.negate(rNum);
            if (rNegNum instanceof BigInteger) {
                stack[frame.stackTop] = rNegNum;
            } else {
                stack[frame.stackTop] = DOUBLE_MARK;
                sDbl[frame.stackTop] = rNegNum.doubleValue();
            }
            return null;
        }
    }

    private static class DoAdd extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object rhs = frame.stack[frame.stackTop];
            Object lhs = frame.stack[--frame.stackTop];
            double d;
            boolean leftRightOrder;
            if (rhs == DOUBLE_MARK) {
                d = frame.doubleStack[frame.stackTop + 1];
                if (lhs == DOUBLE_MARK) {
                    frame.doubleStack[frame.stackTop] += d;
                    return null;
                }
                leftRightOrder = true;
                // fallthrough to object + number code
            } else if (lhs == DOUBLE_MARK) {
                d = frame.doubleStack[frame.stackTop];
                lhs = rhs;
                leftRightOrder = false;
                // fallthrough to object + number code
            } else {
                if (lhs instanceof Scriptable || rhs instanceof Scriptable) {
                    frame.stack[frame.stackTop] = ScriptRuntime.add(lhs, rhs, cx);

                    // the next two else if branches are a bit more tricky
                    // to reduce method calls
                } else if (lhs instanceof CharSequence) {
                    if (rhs instanceof CharSequence) {
                        frame.stack[frame.stackTop] =
                                new ConsString((CharSequence) lhs, (CharSequence) rhs);
                    } else {
                        frame.stack[frame.stackTop] =
                                new ConsString(
                                        (CharSequence) lhs, ScriptRuntime.toCharSequence(rhs));
                    }
                } else if (rhs instanceof CharSequence) {
                    frame.stack[frame.stackTop] =
                            new ConsString(ScriptRuntime.toCharSequence(lhs), (CharSequence) rhs);

                } else {
                    Number lNum =
                            (lhs instanceof Number) ? (Number) lhs : ScriptRuntime.toNumeric(lhs);
                    Number rNum =
                            (rhs instanceof Number) ? (Number) rhs : ScriptRuntime.toNumeric(rhs);

                    if (lNum instanceof BigInteger && rNum instanceof BigInteger) {
                        frame.stack[frame.stackTop] = ((BigInteger) lNum).add((BigInteger) rNum);
                    } else if (lNum instanceof BigInteger || rNum instanceof BigInteger) {
                        throw ScriptRuntime.typeErrorById("msg.cant.convert.to.number", "BigInt");
                    } else {
                        frame.stack[frame.stackTop] = DOUBLE_MARK;
                        frame.doubleStack[frame.stackTop] = lNum.doubleValue() + rNum.doubleValue();
                    }
                }
                return null;
            }

            // handle object(lhs) + number(d) code
            if (lhs instanceof Scriptable) {
                rhs = ScriptRuntime.wrapNumber(d);
                if (!leftRightOrder) {
                    Object tmp = lhs;
                    lhs = rhs;
                    rhs = tmp;
                }
                frame.stack[frame.stackTop] = ScriptRuntime.add(lhs, rhs, cx);
            } else if (lhs instanceof CharSequence) {
                CharSequence rstr = ScriptRuntime.numberToString(d, 10);
                if (leftRightOrder) {
                    frame.stack[frame.stackTop] = new ConsString((CharSequence) lhs, rstr);
                } else {
                    frame.stack[frame.stackTop] = new ConsString(rstr, (CharSequence) lhs);
                }
            } else {
                Number lNum = (lhs instanceof Number) ? (Number) lhs : ScriptRuntime.toNumeric(lhs);
                if (lNum instanceof BigInteger) {
                    throw ScriptRuntime.typeErrorById("msg.cant.convert.to.number", "BigInt");
                } else {
                    frame.stack[frame.stackTop] = DOUBLE_MARK;
                    frame.doubleStack[frame.stackTop] = lNum.doubleValue() + d;
                }
            }
            return null;
        }
    }

    private static class DoArithmetic extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object[] stack = frame.stack;
            double[] sDbl = frame.doubleStack;
            if (stack[frame.stackTop] == DOUBLE_MARK && stack[frame.stackTop - 1] == DOUBLE_MARK) {
                doFastArithemtic(cx, frame, state, op);
                return null;
            }

            Number lNum = stack_numeric(frame, frame.stackTop - 1);
            Number rNum = stack_numeric(frame, frame.stackTop);
            --frame.stackTop;

            Number result = null;
            switch (op) {
                case Token.SUB:
                    result = ScriptRuntime.subtract(lNum, rNum);
                    break;
                case Token.MUL:
                    result = ScriptRuntime.multiply(lNum, rNum);
                    break;
                case Token.DIV:
                    result = ScriptRuntime.divide(lNum, rNum);
                    break;
                case Token.MOD:
                    result = ScriptRuntime.remainder(lNum, rNum);
                    break;
                case Token.EXP:
                    result = ScriptRuntime.exponentiate(lNum, rNum);
                    break;
            }

            if (result instanceof BigInteger) {
                stack[frame.stackTop] = result;
            } else {
                stack[frame.stackTop] = DOUBLE_MARK;
                sDbl[frame.stackTop] = result.doubleValue();
            }
            return null;
        }

        private static NewState doFastArithemtic(
                Context cx, CallFrame frame, InterpreterState state, int op) {
            Object[] stack = frame.stack;
            double[] sDbl = frame.doubleStack;
            double lNum = sDbl[frame.stackTop - 1];
            double rNum = sDbl[frame.stackTop];
            frame.stackTop--;

            double result = 0.0;
            switch (op) {
                case Token.SUB:
                    result = lNum - rNum;
                    break;
                case Token.MUL:
                    result = lNum * rNum;
                    break;
                case Token.DIV:
                    result = lNum / rNum;
                    break;
                case Token.MOD:
                    result = lNum % rNum;
                    break;
                case Token.EXP:
                    result = Math.pow(lNum, rNum);
                    break;
            }

            stack[frame.stackTop] = DOUBLE_MARK;
            sDbl[frame.stackTop] = result;
            return null;
        }
    }

    private static class DoNot extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            stack[frame.stackTop] = !stack_boolean(frame, frame.stackTop);
            return null;
        }
    }

    private static class DoBindName extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            stack[++frame.stackTop] = ScriptRuntime.bind(cx, frame.scope, state.stringReg);
            return null;
        }
    }

    private static class DoSetName extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Object rhs = stack[frame.stackTop];
            if (rhs == DOUBLE_MARK) rhs = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            VarScope lhs = (VarScope) stack[frame.stackTop - 1];
            stack[frame.stackTop - 1] =
                    op == Token.SETNAME
                            ? ScriptRuntime.setName(lhs, rhs, cx, frame.scope, state.stringReg)
                            : ScriptRuntime.strictSetName(
                                    lhs, rhs, cx, frame.scope, state.stringReg);
            --frame.stackTop;
            return null;
        }
    }

    private static class DoStringConcat extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object rhs = frame.stack[frame.stackTop];
            Object lhs = frame.stack[frame.stackTop - 1];

            if (rhs == DOUBLE_MARK) {
                rhs = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            }
            if (lhs == DOUBLE_MARK) {
                lhs = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop - 1]);
            }

            frame.stack[frame.stackTop - 1] = ScriptRuntime.concat(lhs, rhs);
            --frame.stackTop;
            return null;
        }
    }

    private static class DoSetConst extends InstructionClass {
        @Override
        @SuppressWarnings("unchecked")
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Object rhs = stack[frame.stackTop];
            if (rhs == DOUBLE_MARK) rhs = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            VarScope lhs = (VarScope) stack[frame.stackTop - 1];
            stack[frame.stackTop - 1] = ScriptRuntime.setConst(lhs, rhs, cx, state.stringReg);
            --frame.stackTop;
            return null;
        }
    }

    private static class DoDelName extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object rhs = frame.stack[frame.stackTop];
            if (rhs == DOUBLE_MARK)
                rhs = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            --frame.stackTop;
            Object lhs = frame.stack[frame.stackTop];
            if (lhs == DOUBLE_MARK)
                lhs = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            frame.stack[frame.stackTop] =
                    ScriptRuntime.delete(lhs, rhs, cx, frame.scope, op == Icode.DELNAME);
            return null;
        }
    }

    private static class DoDelPropSuper extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            frame.stackTop -= 1;
            stack[frame.stackTop] = Boolean.FALSE;
            ScriptRuntime.throwDeleteOnSuperPropertyNotAllowed();
            return null;
        }
    }

    private static class DoGetPropNoWarn extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Object lhs = stack[frame.stackTop];
            if (lhs == DOUBLE_MARK) lhs = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            stack[frame.stackTop] =
                    ScriptRuntime.getObjectPropNoWarn(lhs, state.stringReg, cx, frame.scope);
            return null;
        }
    }

    private static class DoGetProp extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Object lhs = stack[frame.stackTop];
            if (lhs == DOUBLE_MARK) lhs = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            stack[frame.stackTop] =
                    ScriptRuntime.getObjectProp(lhs, state.stringReg, cx, frame.scope);
            return null;
        }
    }

    private static class DoGetPropSuper extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            Object superObject = stack[frame.stackTop];
            if (superObject == DOUBLE_MARK) Kit.codeBug();
            stack[frame.stackTop] =
                    ScriptRuntime.getSuperProp(
                            superObject,
                            state.stringReg,
                            cx,
                            frame.scope,
                            frame.thisObj,
                            op == Token.GETPROPNOWARN_SUPER);
            return null;
        }
    }

    private static class DoSetProp extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Object rhs = stack[frame.stackTop];
            if (rhs == DOUBLE_MARK) rhs = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            Object lhs = stack[frame.stackTop - 1];
            if (lhs == DOUBLE_MARK) lhs = ScriptRuntime.wrapNumber(sDbl[frame.stackTop - 1]);
            stack[--frame.stackTop] =
                    ScriptRuntime.setObjectProp(lhs, state.stringReg, rhs, cx, frame.scope);
            return null;
        }
    }

    private static class DoSetPropSuper extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Object rhs = stack[frame.stackTop];
            if (rhs == DOUBLE_MARK) rhs = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            Object superObject = stack[frame.stackTop - 1];
            if (superObject == DOUBLE_MARK) Kit.codeBug();
            stack[--frame.stackTop] =
                    ScriptRuntime.setSuperProp(
                            superObject, state.stringReg, rhs, cx, frame.scope, frame.thisObj);
            return null;
        }
    }

    private static class DoPropIncDec extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            final byte[] iCode = frame.compilerData.itsICode;
            Object lhs = stack[frame.stackTop];
            if (lhs == DOUBLE_MARK) lhs = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            stack[frame.stackTop] =
                    ScriptRuntime.propIncrDecr(
                            lhs, state.stringReg, cx, frame.scope, iCode[frame.pc]);
            ++frame.pc;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.out.println(tname + " " + ctx.compilerData.itsICode[ctx.pc]);
            ++ctx.pc;
        }
    }

    private static class DoGetElem extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Object lhs = stack[--frame.stackTop];
            if (lhs == DOUBLE_MARK) {
                lhs = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            }
            Object value;
            Object id = stack[frame.stackTop + 1];
            if (id != DOUBLE_MARK) {
                value = ScriptRuntime.getObjectElem(lhs, id, cx, frame.scope);
            } else {
                double d = sDbl[frame.stackTop + 1];
                value = ScriptRuntime.getObjectIndex(lhs, d, cx, frame.scope);
            }
            stack[frame.stackTop] = value;
            return null;
        }
    }

    private static class DoGetElemSuper extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Object superObject = stack[--frame.stackTop];
            if (superObject == DOUBLE_MARK) Kit.codeBug();
            Object value;
            Object id = stack[frame.stackTop + 1];
            if (id != DOUBLE_MARK) {
                value = ScriptRuntime.getSuperElem(superObject, id, cx, frame.scope, frame.thisObj);
            } else {
                double d = sDbl[frame.stackTop + 1];
                value = ScriptRuntime.getSuperIndex(superObject, d, cx, frame.scope, frame.thisObj);
            }
            stack[frame.stackTop] = value;
            return null;
        }
    }

    private static class DoSetElem extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Object rhs = stack[frame.stackTop];
            if (rhs == DOUBLE_MARK) {
                rhs = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            }
            frame.stackTop -= 2;
            Object lhs = stack[frame.stackTop];
            if (lhs == DOUBLE_MARK) {
                lhs = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            }
            Object value;
            Object id = stack[frame.stackTop + 1];
            if (id != DOUBLE_MARK) {
                value = ScriptRuntime.setObjectElem(lhs, id, rhs, cx, frame.scope);
            } else {
                double d = sDbl[frame.stackTop + 1];
                value = ScriptRuntime.setObjectIndex(lhs, d, rhs, cx, frame.scope);
            }
            stack[frame.stackTop] = value;
            return null;
        }
    }

    private static class DoSetElemSuper extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Object rhs = stack[frame.stackTop];
            if (rhs == DOUBLE_MARK) {
                rhs = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            }
            frame.stackTop -= 2;
            Object superObject = stack[frame.stackTop];
            if (superObject == DOUBLE_MARK) Kit.codeBug();
            Object value;
            Object id = stack[frame.stackTop + 1];
            if (id != DOUBLE_MARK) {
                value =
                        ScriptRuntime.setSuperElem(
                                superObject, id, rhs, cx, frame.scope, frame.thisObj);
            } else {
                double d = sDbl[frame.stackTop + 1];
                value =
                        ScriptRuntime.setSuperIndex(
                                superObject, d, rhs, cx, frame.scope, frame.thisObj);
            }
            stack[frame.stackTop] = value;
            return null;
        }
    }

    private static class DoElemIncDec extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            final byte[] iCode = frame.compilerData.itsICode;
            Object rhs = stack[frame.stackTop];
            if (rhs == DOUBLE_MARK) rhs = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            --frame.stackTop;
            Object lhs = stack[frame.stackTop];
            if (lhs == DOUBLE_MARK) lhs = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            stack[frame.stackTop] =
                    ScriptRuntime.elemIncrDecr(lhs, rhs, cx, frame.scope, iCode[frame.pc]);
            ++frame.pc;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.out.println(tname + " " + ctx.compilerData.itsICode[ctx.pc]);
            ++ctx.pc;
        }
    }

    private static class DoGetRef extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            Ref ref = (Ref) stack[frame.stackTop];
            var res = ScriptRuntime.refGet(ref, cx);
            stack[frame.stackTop] = res;
            return null;
        }
    }

    private static class DoSetRef extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Object value = stack[frame.stackTop];
            if (value == DOUBLE_MARK) value = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            Ref ref = (Ref) stack[frame.stackTop - 1];
            stack[--frame.stackTop] = ScriptRuntime.refSet(ref, value, cx, frame.scope);
            return null;
        }
    }

    private static class DoDelRef extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            Ref ref = (Ref) stack[frame.stackTop];
            stack[frame.stackTop] = ScriptRuntime.refDel(ref, cx);
            return null;
        }
    }

    private static class DoRefIncDec extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final byte[] iCode = frame.compilerData.itsICode;
            Ref ref = (Ref) stack[frame.stackTop];
            stack[frame.stackTop] =
                    ScriptRuntime.refIncrDecr(ref, cx, frame.scope, iCode[frame.pc]);
            ++frame.pc;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.out.println(tname + " " + ctx.compilerData.itsICode[ctx.pc]);
            ++ctx.pc;
        }
    }

    private static class DoLocalLoad extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            final InterpreterData compilerData = frame.compilerData;
            ++frame.stackTop;
            state.indexReg += compilerData.maxVars;
            stack[frame.stackTop] = stack[state.indexReg];
            sDbl[frame.stackTop] = sDbl[state.indexReg];
            return null;
        }
    }

    private static class DoLocalClear extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final InterpreterData compilerData = frame.compilerData;
            state.indexReg += compilerData.maxVars;
            stack[state.indexReg] = null;
            return null;
        }
    }

    private static class DoNameAndThis extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            // stringReg: name
            stack[++frame.stackTop] =
                    ScriptRuntime.getNameAndThis(state.stringReg, cx, frame.scope);
            return null;
        }
    }

    private static class DoNameAndThisOptional extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            stack[++frame.stackTop] =
                    ScriptRuntime.getNameAndThisOptional(state.stringReg, cx, frame.scope);
            return null;
        }
    }

    private static class DoPropAndThis extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Object obj = stack[frame.stackTop];
            if (obj == DOUBLE_MARK) obj = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            // stringReg: property
            stack[frame.stackTop] =
                    ScriptRuntime.getPropAndThis(obj, state.stringReg, cx, frame.scope);
            return null;
        }
    }

    private static class DoPropAndThisOptional extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Object obj = stack[frame.stackTop];
            if (obj == DOUBLE_MARK) obj = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            // stringReg: property
            stack[frame.stackTop] =
                    ScriptRuntime.getPropAndThisOptional(obj, state.stringReg, cx, frame.scope);
            return null;
        }
    }

    private static class DoElemAndThis extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Object obj = stack[frame.stackTop - 1];
            if (obj == DOUBLE_MARK) obj = ScriptRuntime.wrapNumber(sDbl[frame.stackTop - 1]);
            Object id = stack[frame.stackTop];
            if (id == DOUBLE_MARK) id = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            stack[--frame.stackTop] = ScriptRuntime.getElemAndThis(obj, id, cx, frame.scope);
            return null;
        }
    }

    private static class DoElemAndThisOptional extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Object obj = stack[frame.stackTop - 1];
            if (obj == DOUBLE_MARK) obj = ScriptRuntime.wrapNumber(sDbl[frame.stackTop - 1]);
            Object id = stack[frame.stackTop];
            if (id == DOUBLE_MARK) id = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            stack[--frame.stackTop] =
                    ScriptRuntime.getElemAndThisOptional(obj, id, cx, frame.scope);
            return null;
        }
    }

    private static class DoValueAndThis extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            final Object[] stack = frame.stack;
            final double[] sDbl = frame.doubleStack;
            Object value = stack[frame.stackTop];
            if (value == DOUBLE_MARK) value = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            stack[frame.stackTop] = ScriptRuntime.getValueAndThis(value, cx);
            return null;
        }
    }

    private static class DoValueAndThisOptional extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object[] stack = frame.stack;
            double[] sDbl = frame.doubleStack;
            Object value = stack[frame.stackTop];
            if (value == DOUBLE_MARK) value = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            stack[frame.stackTop] = ScriptRuntime.getValueAndThisOptional(value, cx);
            return null;
        }
    }

    private static class DoCallSpecial extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object[] stack = frame.stack;
            double[] sDbl = frame.doubleStack;
            byte[] iCode = frame.compilerData.itsICode;
            boolean isOptionalChainingCall = (op == Icode.CALLSPECIAL_OPTIONAL);

            if (state.instructionCounting) {
                cx.instructionCount += INVOCATION_COST;
            }
            int callType = iCode[frame.pc] & 0xFF;
            boolean isNew = (iCode[frame.pc + 1] != 0);
            int sourceLine = getIndex(iCode, frame.pc + 2);

            // indexReg: number of arguments
            if (isNew) {
                // stack change: function arg0 .. argN -> newResult
                frame.stackTop -= state.indexReg;

                Object function = stack[frame.stackTop];
                if (function == DOUBLE_MARK)
                    function = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
                Object[] outArgs = getArgsArray(stack, sDbl, frame.stackTop + 1, state.indexReg);
                stack[frame.stackTop] =
                        ScriptRuntime.newSpecial(cx, function, outArgs, frame.scope, callType);
            } else {
                // stack change: function thisObj arg0 .. argN -> result
                frame.stackTop -= state.indexReg;

                // Call code generation ensure that stack here
                // is ... Callable Scriptable
                ScriptRuntime.LookupResult result =
                        (ScriptRuntime.LookupResult) stack[frame.stackTop];
                Object[] outArgs = getArgsArray(stack, sDbl, frame.stackTop + 1, state.indexReg);
                Callable function = result.getCallable();
                stack[frame.stackTop] =
                        ScriptRuntime.callSpecial(
                                cx,
                                function,
                                result.getThis(),
                                outArgs,
                                frame.scope,
                                frame.thisObj,
                                callType,
                                frame.fnOrScript.getDescriptor().getSourceName(),
                                sourceLine,
                                isOptionalChainingCall);
            }
            frame.pc += 4;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            int callType = ctx.compilerData.itsICode[ctx.pc] & 0xFF;
            boolean isNew = (ctx.compilerData.itsICode[ctx.pc + 1] != 0);
            int line = ctx.getIndex(ctx.pc + 2);
            ctx.out.println(tname + " " + callType + " " + isNew + " " + ctx.indexReg + " " + line);
            ctx.pc += 4;
        }
    }

    private static class DoCallByteCode extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {

            Object[] stack = frame.stack;
            double[] sDbl = frame.doubleStack;
            Object[] boundArgs = null;
            int blen = 0;

            if (state.instructionCounting) {
                cx.instructionCount += INVOCATION_COST;
            }
            // stack change: lookup_result arg0 .. argN -> result
            // indexReg: number of arguments
            frame.stackTop -= state.indexReg;
            ScriptRuntime.LookupResult result = (ScriptRuntime.LookupResult) stack[frame.stackTop];
            // Check if the lookup result is a function and throw if it's not
            // must not be done sooner according to the spec
            Callable fun = result.getCallable();
            Scriptable funThisObj = result.getThis();
            Scriptable funHomeObj =
                    (fun instanceof BaseFunction) ? ((BaseFunction) fun).getHomeObject() : null;
            if (op == Icode.CALL_ON_SUPER) {
                // funThisObj would have been the "super" object, which we
                // used to lookup the function. Now that that's done, we
                // discard it and invoke the function with the current
                // "this".
                funThisObj = frame.thisObj;
            }

            if (op == Token.REF_CALL) {
                Object[] outArgs = getArgsArray(stack, sDbl, frame.stackTop + 1, state.indexReg);
                stack[frame.stackTop] =
                        ScriptRuntime.callRef(
                                fun, funThisObj,
                                outArgs, cx);
                return null;
            }
            VarScope callerScope = frame.scope;
            // Iteratively reduce known function types: arrows, lambdas,
            // bound functions, call/apply, and no-such-method-handler in
            // order to make a best-effort to keep them in this interpreter
            // loop so continuations keep working. The loop initializer and
            // condition are formulated so that they short-circuit the loop
            // if the function is already an interpreted function, which
            // should be the majority of cases.
            for (; ; ) {
                if (BaseFunction.isApplyOrCall(fun)) {
                    // funThisObj becomes fun
                    var target = ScriptRuntime.getCallable(funThisObj);
                    // first arg becomes thisObj
                    funThisObj =
                            getApplyThis(
                                    cx,
                                    stack,
                                    sDbl,
                                    boundArgs,
                                    frame.stackTop + 1,
                                    state.indexReg,
                                    (Function) target,
                                    frame);
                    if (BaseFunction.isApply(fun)) {
                        // Apply: second argument after new "this"
                        // should be array-like
                        // and we'll spread its elements on the stack
                        final Object[] callArgs;
                        if (blen > 1) {
                            callArgs = ScriptRuntime.getApplyArguments(cx, boundArgs[1]);
                        } else if (state.indexReg < 2) {
                            callArgs = ScriptRuntime.emptyArgs;
                        } else {
                            callArgs =
                                    ScriptRuntime.getApplyArguments(
                                            cx, stack[frame.stackTop - blen + 2]);
                        }

                        int alen = callArgs.length;
                        // We're coming from the outside, so this
                        // is replacing any bound args we might
                        // have had already.
                        boundArgs = callArgs;
                        blen = alen;
                        state.indexReg = alen;
                    } else {
                        // Call: shift args left, starting from 2nd
                        if (state.indexReg > 0) {
                            if (state.indexReg > 1 && blen == 0) {
                                System.arraycopy(
                                        stack,
                                        frame.stackTop + 2,
                                        stack,
                                        frame.stackTop + 1,
                                        state.indexReg - 1);
                                System.arraycopy(
                                        sDbl,
                                        frame.stackTop + 2,
                                        sDbl,
                                        frame.stackTop + 1,
                                        state.indexReg - 1);
                            } else if (state.indexReg > 1) {
                                Object[] newBArgs = new Object[boundArgs.length - 1];
                                System.arraycopy(boundArgs, 1, newBArgs, 0, boundArgs.length - 1);
                                boundArgs = newBArgs;
                                blen = newBArgs.length;
                            } else {
                                // Bound args is 1 long.
                                boundArgs = new Object[0];
                                blen = 0;
                            }
                            state.indexReg--;
                        }
                    }
                    fun = target;
                } else if (fun instanceof LambdaConstructor) {
                    break;
                } else if (fun instanceof LambdaFunction) {
                    break;
                } else if (fun instanceof BoundFunction) {
                    BoundFunction bfun = (BoundFunction) fun;
                    fun = bfun.getTargetFunction();
                    funThisObj = bfun.getCallThis();

                    Object[] bArgs = bfun.getBoundArgs();
                    boundArgs = addBoundArgs(boundArgs, bArgs);
                    blen = blen + bArgs.length;
                    state.indexReg += bArgs.length;
                } else if (fun instanceof NoSuchMethodShim) {
                    NoSuchMethodShim nsmfun = (NoSuchMethodShim) fun;
                    // Bug 447697 -- make best effort to keep
                    // __noSuchMethod__ within this interpreter loop
                    // invocation.
                    Object[] elements =
                            getArgsArray(
                                    stack,
                                    sDbl,
                                    boundArgs,
                                    blen,
                                    frame.stackTop + 1,
                                    state.indexReg);
                    fun = nsmfun.noSuchMethodMethod;
                    boundArgs = new Object[2];
                    blen = 2;
                    boundArgs[0] = nsmfun.methodName;
                    boundArgs[1] = cx.newArray(callerScope, elements);
                    state.indexReg = 2;
                } else if (fun == null) {
                    throw ScriptRuntime.notFunctionError(null, null);
                } else {
                    // Current function is something that we can't reduce
                    // further.
                    break;
                }
            }

            if (fun instanceof JSFunction
                    && ((JSFunction) fun).getDescriptor().getCode() instanceof InterpreterData) {
                JSFunction ifun = (JSFunction) fun;

                JSDescriptor<JSFunction> desc = ifun.getDescriptor();
                var compilerData = (InterpreterData<JSFunction>) desc.getCode();
                if (frame.fnOrScript.getDescriptor().getSecurityDomain()
                        == desc.getSecurityDomain()) {
                    CallFrame callParentFrame = frame;
                    if (op == Icode.TAIL_CALL) {
                        // In principle tail call can re-use the current
                        // frame and its stack arrays but it is hard to
                        // do properly. Any exceptions that can legally
                        // happen during frame re-initialization including
                        // StackOverflowException during innocent looking
                        // System.arraycopy may leave the current frame
                        // data corrupted leading to undefined behaviour
                        // in the catch code bellow that unwinds JS stack
                        // on exceptions. Then there is issue about frame
                        // release
                        // end exceptions there.
                        // To avoid frame allocation a released frame
                        // can be cached for re-use which would also benefit
                        // non-tail calls but it is not clear that this
                        // caching
                        // would gain in performance due to potentially
                        // bad interaction with GC.
                        callParentFrame = frame.parentFrame;
                        // Release the current frame. See Bug #344501 to see
                        // why
                        // it is being done here.
                        exitFrame(cx, frame, null);
                    }

                    CallFrame calleeFrame =
                            initFrame(
                                    cx,
                                    ifun.getDeclarationScope(),
                                    ifun.getThisObj(funThisObj),
                                    funHomeObj,
                                    stack,
                                    sDbl,
                                    boundArgs,
                                    frame.stackTop + 1,
                                    state.indexReg,
                                    ifun,
                                    compilerData,
                                    callParentFrame);
                    if (op != Icode.TAIL_CALL) {
                        frame.savedCallOp = op;
                    }
                    return new StateContinueResult(calleeFrame, state.indexReg);
                }
            }

            if (fun instanceof NativeContinuation) {
                // Jump to the captured continuation
                var cjump = new ContinuationJump<>((NativeContinuation) fun, frame);

                // continuation result is the first argument if any
                // of continuation call
                if (state.indexReg == 0) {
                    cjump.result = undefined;
                } else {
                    cjump.result = stack[frame.stackTop + 1];
                    cjump.resultDbl = sDbl[frame.stackTop + 1];
                }

                // Start the real unwind job
                state.throwable = cjump;
                return BREAK_WITHOUT_EXTENSION;
            }

            if (fun instanceof JSFunction) {
                var ifun = (JSFunction) fun;

                if (NativeContinuation.isContinuationConstructor(ifun)) {
                    frame.stack[frame.stackTop] = captureContinuation(cx, frame.parentFrame, false);
                    return null;
                }
            }

            frame.savedCallOp = op;
            stack[frame.stackTop] =
                    fun.call(
                            cx,
                            callerScope,
                            funThisObj,
                            getArgsArray(
                                    stack,
                                    sDbl,
                                    boundArgs,
                                    blen,
                                    frame.stackTop + 1,
                                    state.indexReg));

            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.out.println(tname + " " + ctx.indexReg);
        }
    }

    private static class DoNew extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            if (state.instructionCounting) {
                cx.instructionCount += INVOCATION_COST;
            }
            // stack change: function arg0 .. argN -> newResult
            // state.indexReg: number of arguments
            frame.stackTop -= state.indexReg;

            Object lhs = frame.stack[frame.stackTop];
            if (lhs instanceof JSFunction
                    && ((JSFunction) lhs).getConstructor() instanceof InterpreterData) {
                JSFunction f = (JSFunction) lhs;

                JSDescriptor<JSFunction> desc = f.getDescriptor();
                var compilerData = (InterpreterData<JSFunction>) desc.getConstructor();
                if (frame.fnOrScript.getDescriptor().getSecurityDomain()
                        == desc.getSecurityDomain()) {
                    if (cx.getLanguageVersion() >= Context.VERSION_ES6
                            && f.getHomeObject() != null) {
                        // Only methods have home objects associated with
                        // them
                        throw ScriptRuntime.typeErrorById("msg.not.ctor", f.getFunctionName());
                    }

                    Scriptable newInstance =
                            f.getHomeObject() == null ? f.createObject(cx, frame.scope) : null;
                    CallFrame calleeFrame =
                            initFrame(
                                    cx,
                                    frame.scope,
                                    newInstance,
                                    newInstance,
                                    frame.stack,
                                    frame.doubleStack,
                                    null,
                                    frame.stackTop + 1,
                                    state.indexReg,
                                    f,
                                    compilerData,
                                    frame);

                    frame.stack[frame.stackTop] = newInstance;
                    frame.savedCallOp = op;
                    return new StateContinueResult(calleeFrame, state.indexReg);
                }
            }
            if (lhs instanceof JSFunction) {
                var f = (JSFunction) lhs;

                if (NativeContinuation.isContinuationConstructor(f)) {
                    frame.stack[frame.stackTop] = captureContinuation(cx, frame.parentFrame, false);
                    return null;
                }
            }

            if (!(lhs instanceof Constructable)) {
                if (lhs == DOUBLE_MARK)
                    lhs = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
                throw ScriptRuntime.notFunctionError(lhs);
            }
            Constructable ctor = (Constructable) lhs;

            Object[] outArgs =
                    getArgsArray(
                            frame.stack, frame.doubleStack, frame.stackTop + 1, state.indexReg);
            frame.stack[frame.stackTop] = ctor.construct(cx, frame.scope, outArgs);
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.out.println(tname + " " + ctx.indexReg);
        }
    }

    private static class DoTypeOf extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object[] stack = frame.stack;
            double[] sDbl = frame.doubleStack;
            Object lhs = stack[frame.stackTop];
            if (lhs == DOUBLE_MARK) lhs = ScriptRuntime.wrapNumber(sDbl[frame.stackTop]);
            stack[frame.stackTop] = ScriptRuntime.typeof(lhs);
            return null;
        }
    }

    private static class DoTypeOfName extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            frame.stack[++frame.stackTop] = ScriptRuntime.typeofName(frame.scope, state.stringReg);
            return null;
        }
    }

    private static class DoString extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            frame.stack[++frame.stackTop] = state.stringReg;
            return null;
        }
    }

    private static class DoShortNumber extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            ++frame.stackTop;
            frame.stack[frame.stackTop] = DOUBLE_MARK;
            frame.doubleStack[frame.stackTop] = getShort(frame.compilerData.itsICode, frame.pc);
            frame.pc += 2;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            int value = ctx.getShort(ctx.pc);
            ctx.out.println(tname + " " + value);
            ctx.pc += 2;
        }
    }

    private static class DoIntNumber extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            ++frame.stackTop;
            frame.stack[frame.stackTop] = DOUBLE_MARK;
            frame.doubleStack[frame.stackTop] = getInt(frame.compilerData.itsICode, frame.pc);
            frame.pc += 4;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            int value = ctx.getInt(ctx.pc);
            ctx.out.println(tname + " " + value);
            ctx.pc += 4;
        }
    }

    private static class DoNumber extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            ++frame.stackTop;
            frame.stack[frame.stackTop] = DOUBLE_MARK;
            frame.doubleStack[frame.stackTop] = frame.compilerData.itsDoubleTable[state.indexReg];
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            double value = ctx.compilerData.itsDoubleTable[ctx.indexReg];
            ctx.out.println(tname + " " + value);
        }
    }

    private static class DoBigInt extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            frame.stack[++frame.stackTop] = state.bigIntReg;
            return null;
        }
    }

    private static class DoName extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            frame.stack[++frame.stackTop] = ScriptRuntime.name(cx, frame.scope, state.stringReg);
            return null;
        }
    }

    private static class DoNameIncDec extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            frame.stack[++frame.stackTop] =
                    ScriptRuntime.nameIncrDecr(
                            frame.scope,
                            state.stringReg,
                            cx,
                            frame.compilerData.itsICode[frame.pc]);
            ++frame.pc;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.out.println(tname + " " + ctx.compilerData.itsICode[ctx.pc]);
            ++ctx.pc;
        }
    }

    private static class DoSetConstVar1 extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.indexReg = frame.compilerData.itsICode[frame.pc++];
            var varAttributes = frame.varSource.stackAttributes;
            var vars = frame.varSource.stack;
            var varDbls = frame.varSource.doubleStack;
            if ((varAttributes[state.indexReg] & ScriptableObject.READONLY) == 0) {
                throw Context.reportRuntimeErrorById(
                        "msg.var.redecl",
                        frame.fnOrScript.getDescriptor().getParamOrVarName(state.indexReg));
            }
            if ((varAttributes[state.indexReg] & ScriptableObject.UNINITIALIZED_CONST) != 0) {
                vars[state.indexReg] = frame.stack[frame.stackTop];
                varAttributes[state.indexReg] &= ~ScriptableObject.UNINITIALIZED_CONST;
                varDbls[state.indexReg] = frame.doubleStack[frame.stackTop];
            }
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.indexReg = ctx.compilerData.itsICode[ctx.pc];
            ctx.out.println(tname + " " + ctx.indexReg);
            ++ctx.pc;
        }
    }

    private static class DoSetConstVar extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            var varAttributes = frame.varSource.stackAttributes;
            var vars = frame.varSource.stack;
            var varDbls = frame.varSource.doubleStack;
            if ((varAttributes[state.indexReg] & ScriptableObject.READONLY) == 0) {
                throw Context.reportRuntimeErrorById(
                        "msg.var.redecl",
                        frame.fnOrScript.getDescriptor().getParamOrVarName(state.indexReg));
            }

            // HtmlUnit - HACK
            // disable this to allow const updates in loops
            // see JavaScriptEngine2Test.constInLoop()
            //
            // HtmlUnit - HACK
            //  if ((varAttributes[state.indexReg] & ScriptableObject.UNINITIALIZED_CONST) != 0) {
            // HtmlUnit - HACK
                vars[state.indexReg] = frame.stack[frame.stackTop];
                varAttributes[state.indexReg] &= ~ScriptableObject.UNINITIALIZED_CONST;
                varDbls[state.indexReg] = frame.doubleStack[frame.stackTop];
            // HtmlUnit - HACK
            // }
            // HtmlUnit - HACK
            return null;
        }
    }

    private static class DoSetVar1 extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.indexReg = frame.compilerData.itsICode[frame.pc++];
            var varAttributes = frame.varSource.stackAttributes;
            var vars = frame.varSource.stack;
            var varDbls = frame.varSource.doubleStack;
            if ((varAttributes[state.indexReg] & ScriptableObject.READONLY) == 0) {
                vars[state.indexReg] = frame.stack[frame.stackTop];
                varDbls[state.indexReg] = frame.doubleStack[frame.stackTop];
            }
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.indexReg = ctx.compilerData.itsICode[ctx.pc];
            ctx.out.println(tname + " " + ctx.indexReg);
            ++ctx.pc;
        }
    }

    private static class DoSetVar extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            var varAttributes = frame.varSource.stackAttributes;
            var vars = frame.varSource.stack;
            var varDbls = frame.varSource.doubleStack;
            if ((varAttributes[state.indexReg] & ScriptableObject.READONLY) == 0) {
                vars[state.indexReg] = frame.stack[frame.stackTop];
                varDbls[state.indexReg] = frame.doubleStack[frame.stackTop];
            }
            return null;
        }
    }

    private static class DoGetVar1 extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.indexReg = frame.compilerData.itsICode[frame.pc++];
            var vars = frame.varSource.stack;
            var varDbls = frame.varSource.doubleStack;
            ++frame.stackTop;
            frame.stack[frame.stackTop] = vars[state.indexReg];
            frame.doubleStack[frame.stackTop] = varDbls[state.indexReg];
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.indexReg = ctx.compilerData.itsICode[ctx.pc];
            ctx.out.println(tname + " " + ctx.indexReg);
            ++ctx.pc;
        }
    }

    private static class DoGetVar extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            var vars = frame.varSource.stack;
            var varDbls = frame.varSource.doubleStack;
            ++frame.stackTop;
            frame.stack[frame.stackTop] = vars[state.indexReg];
            frame.doubleStack[frame.stackTop] = varDbls[state.indexReg];
            return null;
        }
    }

    private static class DoVarIncDec extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            var varAttributes = frame.varSource.stackAttributes;
            var vars = frame.varSource.stack;
            var varDbls = frame.varSource.doubleStack;
            // indexReg : varindex
            ++frame.stackTop;
            int incrDecrMask = frame.compilerData.itsICode[frame.pc];
            Object varValue = vars[state.indexReg];
            double d = 0.0;
            BigInteger bi = null;
            if (varValue == DOUBLE_MARK) {
                d = varDbls[state.indexReg];
            } else {
                Number num = ScriptRuntime.toNumeric(varValue);
                if (num instanceof BigInteger) {
                    bi = (BigInteger) num;
                } else {
                    d = num.doubleValue();
                }
            }
            if (bi == null) {
                // double
                double d2 = ((incrDecrMask & Node.DECR_FLAG) == 0) ? d + 1.0 : d - 1.0;
                boolean post = ((incrDecrMask & Node.POST_FLAG) != 0);
                if ((varAttributes[state.indexReg] & ScriptableObject.READONLY) == 0) {
                    if (varValue != DOUBLE_MARK) {
                        vars[state.indexReg] = DOUBLE_MARK;
                    }
                    varDbls[state.indexReg] = d2;
                    frame.stack[frame.stackTop] = DOUBLE_MARK;
                    frame.doubleStack[frame.stackTop] = post ? d : d2;
                } else {
                    if (post && varValue != DOUBLE_MARK) {
                        frame.stack[frame.stackTop] = varValue;
                    } else {
                        frame.stack[frame.stackTop] = DOUBLE_MARK;
                        frame.doubleStack[frame.stackTop] = post ? d : d2;
                    }
                }
            } else {
                // BigInt
                BigInteger result;
                if ((incrDecrMask & Node.DECR_FLAG) == 0) {
                    result = bi.add(BigInteger.ONE);
                } else {
                    result = bi.subtract(BigInteger.ONE);
                }

                boolean post = ((incrDecrMask & Node.POST_FLAG) != 0);
                if ((varAttributes[state.indexReg] & ScriptableObject.READONLY) == 0) {
                    vars[state.indexReg] = result;
                    frame.stack[frame.stackTop] = post ? bi : result;
                } else {
                    if (post && varValue != DOUBLE_MARK) {
                        frame.stack[frame.stackTop] = varValue;
                    } else {
                        frame.stack[frame.stackTop] = post ? bi : result;
                    }
                }
            }
            ++frame.pc;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.out.println(tname + " " + ctx.compilerData.itsICode[ctx.pc]);
            ++ctx.pc;
        }
    }

    private static class DoZero extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            ++frame.stackTop;
            frame.stack[frame.stackTop] = Integer.valueOf(0);
            return null;
        }
    }

    private static class DoOne extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            ++frame.stackTop;
            frame.stack[frame.stackTop] = Integer.valueOf(1);
            return null;
        }
    }

    private static class DoNull extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            frame.stack[++frame.stackTop] = null;
            return null;
        }
    }

    private static class DoThis extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            frame.stack[++frame.stackTop] = frame.thisObj;
            return null;
        }
    }

    private static class DoSuper extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            // If we are referring to "super", then we always have an
            // activation
            // (this is done in IrFactory). The home object is stored as
            // part of the
            // activation frame to propagate it correctly for nested
            // functions.
            Scriptable homeObject = frame.fnOrScript.getHomeObject();
            if (homeObject == null) {
                // This if is specified in the spec, but I cannot imagine
                // how the home object will ever be null since `super` is
                // legal _only_ in method definitions, where we do have a
                // home object!
                frame.stack[++frame.stackTop] = Undefined.instance;
            } else {
                frame.stack[++frame.stackTop] = homeObject.getPrototype();
            }
            return null;
        }
    }

    private static class DoThisFunction extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            frame.stack[++frame.stackTop] = frame.fnOrScript;
            return null;
        }
    }

    private static class DoFalse extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            frame.stack[++frame.stackTop] = Boolean.FALSE;
            return null;
        }
    }

    private static class DoTrue extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            frame.stack[++frame.stackTop] = Boolean.TRUE;
            return null;
        }
    }

    private static class DoUndef extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            frame.stack[++frame.stackTop] = undefined;
            return null;
        }
    }

    private static class DoEnterWith extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object lhs = frame.stack[frame.stackTop];
            if (lhs == DOUBLE_MARK)
                lhs = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            frame.scope = ScriptRuntime.enterWith(lhs, cx, frame.scope);
            frame.stackTop--;
            return null;
        }
    }

    private static class DoLeaveWith extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            frame.scope = ScriptRuntime.leaveWith(frame.scope);
            return null;
        }
    }

    private static class DoCatchScope extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {

            // stack top: exception object
            // state.stringReg: name of exception variable
            // state.indexReg: local for exception scope
            --frame.stackTop;
            state.indexReg += frame.compilerData.maxVars;

            boolean afterFirstScope = (frame.compilerData.itsICode[frame.pc] != 0);
            Throwable caughtException = (Throwable) frame.stack[frame.stackTop + 1];
            Scriptable lastCatchScope;
            if (!afterFirstScope) {
                lastCatchScope = null;
            } else {
                lastCatchScope = (Scriptable) frame.stack[state.indexReg];
            }
            frame.stack[state.indexReg] =
                    ScriptRuntime.newCatchScope(
                            caughtException, lastCatchScope, state.stringReg, cx, frame.scope);
            ++frame.pc;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            boolean afterFisrtFlag = (ctx.compilerData.itsICode[ctx.pc] != 0);
            ctx.out.println(tname + " " + afterFisrtFlag);
            ++ctx.pc;
        }
    }

    private static class DoEnumInit extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object lhs = frame.stack[frame.stackTop];
            if (lhs == DOUBLE_MARK)
                lhs = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            state.indexReg += frame.compilerData.maxVars;
            int enumType =
                    op == Token.ENUM_INIT_KEYS
                            ? cx.getLanguageVersion() <= Context.VERSION_1_8
                                    ? ScriptRuntime.ENUMERATE_KEYS
                                    : ScriptRuntime.ENUMERATE_KEYS_NO_ITERATOR
                            : op == Token.ENUM_INIT_VALUES
                                    ? ScriptRuntime.ENUMERATE_VALUES
                                    : op == Token.ENUM_INIT_VALUES_IN_ORDER
                                            ? ScriptRuntime.ENUMERATE_VALUES_IN_ORDER
                                            : ScriptRuntime.ENUMERATE_ARRAY;
            frame.stack[state.indexReg] = ScriptRuntime.enumInit(lhs, cx, frame.scope, enumType);
            --frame.stackTop;
            return null;
        }
    }

    private static class DoEnumOp extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.indexReg += frame.compilerData.maxVars;
            Object val = frame.stack[state.indexReg];
            frame.stack[++frame.stackTop] =
                    (op == Token.ENUM_NEXT)
                            ? ScriptRuntime.enumNext(val, cx)
                            : ScriptRuntime.enumId(val, cx);
            return null;
        }
    }

    private static class DoRefSpecial extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            // stringReg: name of special property
            Object obj = frame.stack[frame.stackTop];
            if (obj == DOUBLE_MARK)
                obj = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            frame.stack[frame.stackTop] =
                    ScriptRuntime.specialRef(obj, state.stringReg, cx, frame.scope);
            return null;
        }
    }

    private static class DoRefMember extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object elem = frame.stack[frame.stackTop];
            if (elem == DOUBLE_MARK)
                elem = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            --frame.stackTop;
            Object obj = frame.stack[frame.stackTop];
            if (obj == DOUBLE_MARK)
                obj = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            frame.stack[frame.stackTop] = ScriptRuntime.memberRef(obj, elem, cx, state.indexReg);
            return null;
        }
    }

    private static class DoRefNsMember extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object elem = frame.stack[frame.stackTop];
            if (elem == DOUBLE_MARK)
                elem = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            --frame.stackTop;
            Object ns = frame.stack[frame.stackTop];
            if (ns == DOUBLE_MARK) ns = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            --frame.stackTop;
            Object obj = frame.stack[frame.stackTop];
            if (obj == DOUBLE_MARK)
                obj = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            frame.stack[frame.stackTop] =
                    ScriptRuntime.memberRef(obj, ns, elem, cx, state.indexReg);
            return null;
        }
    }

    private static class DoRefName extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            // indexReg: flags
            Object name = frame.stack[frame.stackTop];
            if (name == DOUBLE_MARK)
                name = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            frame.stack[frame.stackTop] =
                    ScriptRuntime.nameRef(name, cx, frame.scope, state.indexReg);
            return null;
        }
    }

    private static class DoRefNsName extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object name = frame.stack[frame.stackTop];
            if (name == DOUBLE_MARK)
                name = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            --frame.stackTop;
            Object ns = frame.stack[frame.stackTop];
            if (ns == DOUBLE_MARK) ns = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            frame.stack[frame.stackTop] =
                    ScriptRuntime.nameRef(ns, name, cx, frame.scope, state.indexReg);
            return null;
        }
    }

    private static class DoScopeLoad extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.indexReg += frame.compilerData.maxVars;
            frame.scope = (VarScope) frame.stack[state.indexReg];
            return null;
        }
    }

    private static class DoScopeSave extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.indexReg += frame.compilerData.maxVars;
            frame.stack[state.indexReg] = frame.scope;
            return null;
        }
    }

    private static class DoClosureExpr extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            JSFunction fn = createClosure(cx, frame, state.indexReg);
            frame.stack[++frame.stackTop] = fn;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.out.println(tname + " #" + ctx.indexReg);
        }
    }

    private static class DoMethodExpr extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Scriptable homeObject = (Scriptable) frame.stack[frame.stackTop - 1];
            JSFunction fn = createMethod(cx, frame, state.indexReg, homeObject);
            frame.stack[++frame.stackTop] = fn;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.out.println(tname + " #" + ctx.indexReg);
        }
    }

    private static class DoClosureStatement extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            initFunction(cx, frame.scope, frame.fnOrScript.getDescriptor(), state.indexReg);
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.out.println(tname + " #" + ctx.indexReg);
        }
    }

    private static class DoRegExp extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object re = frame.compilerData.itsRegExpLiterals[state.indexReg];
            frame.stack[++frame.stackTop] = ScriptRuntime.wrapRegExp(cx, frame.scope, re);
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.out.println(tname + " " + ctx.compilerData.itsRegExpLiterals[ctx.indexReg]);
        }
    }

    private static class DoTemplateLiteralCallSite extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object[] templateLiterals = frame.compilerData.itsTemplateLiterals;
            frame.stack[++frame.stackTop] =
                    ScriptRuntime.getTemplateLiteralCallSite(
                            cx, frame.scope, templateLiterals, state.indexReg);
            return null;
        }
    }

    private static class DoLiteralNewObject extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            ++frame.pc;
            ++frame.stackTop;
            frame.stack[frame.stackTop] = cx.newObject(frame.scope);
            ++frame.stackTop;

            // indexReg > 0: index of constant with the keys
            // indexReg < 0: we have a spread, so no keys array, but we know the length
            if (state.indexReg < 0) {
                frame.stack[frame.stackTop] =
                        NewLiteralStorage.create(cx, -state.indexReg - 1, true);
            } else {
                Object[] ids = (Object[]) frame.compilerData.literalIds[state.indexReg];
                boolean copyArray = frame.compilerData.itsICode[frame.pc] != 0;
                frame.stack[frame.stackTop] =
                        NewLiteralStorage.create(
                                cx, copyArray ? Arrays.copyOf(ids, ids.length) : ids);
            }

            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            boolean copyArray = ctx.compilerData.itsICode[ctx.pc] != 0;
            if (ctx.indexReg < 0) {
                ctx.out.println(tname + " length: " + (-ctx.indexReg - 1));
            } else {
                Object[] keys = (Object[]) ctx.compilerData.literalIds[ctx.indexReg];
                ctx.out.println(tname + " " + Arrays.toString(keys) + " " + copyArray);
            }
            ++ctx.pc;
        }
    }

    private static class DoLiteralNewArray extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            // indexReg: number of values in the literal
            NewLiteralStorage storage = NewLiteralStorage.create(cx, state.indexReg, false);

            int skipIdx = getIndex(frame.compilerData.itsICode, frame.pc);
            frame.pc += 2;

            // fill in skip indexes in array literal storage
            if (skipIdx > 0) { // 0 - no skip index, otherwise subtract 1 from idx
                storage.setSkipIndexes((int[]) frame.compilerData.literalIds[skipIdx - 1]);
            }

            frame.stack[++frame.stackTop] = storage;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            int skipIdx = getIndex(ctx.compilerData.itsICode, ctx.pc);
            ctx.out.println(tname + " " + ctx.indexReg + " skipIdx=" + skipIdx);
            ctx.pc += 2;
        }
    }

    private static class DoLiteralSet extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object value = frame.stack[frame.stackTop];
            if (value == DOUBLE_MARK)
                value = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            --frame.stackTop;
            var store = (NewLiteralStorage) frame.stack[frame.stackTop];
            store.pushValue(value);
            return null;
        }
    }

    private static class DoLiteralGetter extends InstructionClass {
        @Override
        NewState execute(Context cs, CallFrame frame, InterpreterState state, int op) {
            Object value = frame.stack[frame.stackTop];
            --frame.stackTop;
            var store = (NewLiteralStorage) frame.stack[frame.stackTop];
            store.pushGetter(value);
            return null;
        }
    }

    private static class DoLiteralSetter extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object value = frame.stack[frame.stackTop];
            --frame.stackTop;
            var store = (NewLiteralStorage) frame.stack[frame.stackTop];
            store.pushSetter(value);
            return null;
        }
    }

    private static class DoLiteralKeySet extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object key = frame.stack[frame.stackTop];
            if (key == DOUBLE_MARK)
                key = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            --frame.stackTop;
            var store = (NewLiteralStorage) frame.stack[frame.stackTop];
            store.pushKey(key);
            return null;
        }
    }

    private static class DoSpread extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            // stack: [..., NewLiteralStorage, sourceObj]
            Object source = frame.stack[frame.stackTop];
            --frame.stackTop;
            NewLiteralStorage store = (NewLiteralStorage) frame.stack[frame.stackTop];

            // Always consume the 2-byte operand to keep pc in sync.
            int sourcePos = getIndex(frame.compilerData.itsICode, frame.pc);
            frame.pc += 2;

            if (store.hasSkipIndexes()) {
                store.spread(cx, frame.scope, source, sourcePos);
            } else {
                store.spread(cx, frame.scope, source, 0);
            }
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            int sourcePos = ctx.getIndex(ctx.pc);
            ctx.out.println(tname + " sourcePos=" + sourcePos);
            ctx.pc += 2;
        }
    }

    private static class DoObjectRest extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            // indexReg contains the literalId for static key indices array
            int computedKeyCount = frame.compilerData.itsICode[frame.pc++] & 0xFF;

            // Get static key indices from literalIds using indexReg
            int[] staticKeyIndices = (int[]) frame.compilerData.literalIds[state.indexReg];
            int staticKeyCount = staticKeyIndices.length;

            Object[] excludeKeys = new Object[staticKeyCount + computedKeyCount];

            // Fill static keys from the strings table using stored indices
            for (int i = 0; i < staticKeyCount; i++) {
                excludeKeys[i] = frame.compilerData.itsStringTable[staticKeyIndices[i]];
            }

            // Pop computed keys from stack: [source, computed_key_1, ..., computed_key_N]
            for (int i = computedKeyCount - 1; i >= 0; i--) {
                Object computedKey = frame.stack[frame.stackTop];
                if (computedKey == DOUBLE_MARK) {
                    computedKey = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
                }
                excludeKeys[staticKeyCount + i] = ScriptRuntime.toString(computedKey);
                frame.stackTop--;
            }

            Object source = frame.stack[frame.stackTop];
            if (source == DOUBLE_MARK) {
                source = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            }

            // Create rest object
            Scriptable result = ScriptRuntime.doObjectRest(cx, frame.scope, source, excludeKeys);

            frame.stack[frame.stackTop] = result;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            int computedKeyCount = ctx.compilerData.itsICode[ctx.pc] & 0xFF;
            ++ctx.pc;
            if (ctx.indexReg >= 0) {
                int[] staticKeyIndices = (int[]) ctx.compilerData.literalIds[ctx.indexReg];
                StringBuilder keys = new StringBuilder();
                keys.append("[static: ");
                for (int i = 0; i < staticKeyIndices.length; i++) {
                    if (i > 0) keys.append(", ");
                    keys.append("\"")
                            .append(ctx.compilerData.itsStringTable[staticKeyIndices[i]])
                            .append("\"");
                }
                keys.append("; computed: ").append(computedKeyCount).append("]");
                ctx.out.println(tname + " excluding " + keys);
            } else {
                ctx.out.println(
                        tname
                                + " literalId: "
                                + (-ctx.indexReg - 1)
                                + ", computed: "
                                + computedKeyCount);
            }
        }
    }

    private static class DoObjectLit extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            var store = (NewLiteralStorage) frame.stack[frame.stackTop];
            --frame.stackTop;
            Scriptable object = (Scriptable) frame.stack[frame.stackTop];
            ScriptRuntime.fillObjectLiteral(
                    object,
                    store.getKeys(),
                    store.getValues(),
                    store.getGetterSetters(),
                    cx,
                    frame.scope);
            return null;
        }
    }

    private static class DoArrayLiteral extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            var store = (NewLiteralStorage) frame.stack[frame.stackTop];
            int[] skipIndexes = null;
            if (op == Icode.SPARE_ARRAYLIT) {
                skipIndexes = store.getAdjustedSkipIndexes();
                if (skipIndexes == null) {
                    skipIndexes = (int[]) frame.compilerData.literalIds[state.indexReg];
                }
            }
            frame.stack[frame.stackTop] =
                    ScriptRuntime.newArrayLiteral(store.getValues(), skipIndexes, cx, frame.scope);
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            if (op == Icode.SPARE_ARRAYLIT) {
                ctx.out.println(tname + " " + ctx.compilerData.literalIds[ctx.indexReg]);
            } else {
                ctx.out.println(tname);
            }
        }
    }

    private static class DoEnterDotQuery extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object lhs = frame.stack[frame.stackTop];
            if (lhs == DOUBLE_MARK)
                lhs = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            frame.scope = ScriptRuntime.enterDotQuery(lhs, frame.scope);
            frame.stackTop--;
            return null;
        }
    }

    private static class DoLeaveDotQuery extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            boolean valBln = stack_boolean(frame, frame.stackTop);
            Object x = ScriptRuntime.updateDotQuery(valBln, frame.scope);
            if (x != null) {
                frame.stack[frame.stackTop] = x;
                frame.scope = ScriptRuntime.leaveDotQuery(frame.scope);
                frame.pc += 2;
                return null;
            }
            // reset stack and PC to code after ENTERDQ
            --frame.stackTop;
            return BREAK_JUMPLESSRUN;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            dumpJumpTarget(tname, ctx);
        }
    }

    private static class DoDefaultNamespace extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object value = frame.stack[frame.stackTop];
            if (value == DOUBLE_MARK)
                value = ScriptRuntime.wrapNumber(frame.doubleStack[frame.stackTop]);
            frame.stack[frame.stackTop] = ScriptRuntime.setDefaultNamespace(value, cx);
            return null;
        }
    }

    private static class DoEscXMLAttr extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object value = frame.stack[frame.stackTop];
            if (value != DOUBLE_MARK) {
                frame.stack[frame.stackTop] = ScriptRuntime.escapeAttributeValue(value, cx);
            }
            return null;
        }
    }

    private static class DoEscXMLText extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            Object value = frame.stack[frame.stackTop];
            if (value != DOUBLE_MARK) {
                frame.stack[frame.stackTop] = ScriptRuntime.escapeTextValue(value, cx);
            }
            return null;
        }
    }

    private static class DoDebug extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            if (frame.debuggerFrame != null) {
                frame.debuggerFrame.onDebuggerStatement(cx);
            }
            return null;
        }
    }

    private static class DoLineChange extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            frame.pcSourceLineStart = frame.pc;
            if (frame.debuggerFrame != null) {
                int line = getIndex(frame.compilerData.itsICode, frame.pc);
                frame.debuggerFrame.onLineChange(cx, line);
            }
            frame.pc += 2;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            int line = ctx.getIndex(ctx.pc);
            ctx.out.println(tname + " : " + line);
            ctx.pc += 2;
        }
    }

    private static class DoIndexCn extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.indexReg = Icode.REG_IND_C0 - op;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.indexReg = Icode.REG_IND_C0 - op;
            ctx.out.println(tname);
        }
    }

    private static class DoRegIndex1 extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.indexReg = 0xFF & frame.compilerData.itsICode[frame.pc];
            ++frame.pc;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.indexReg = 0xFF & ctx.compilerData.itsICode[ctx.pc];
            ctx.out.println(tname + " " + ctx.indexReg);
            ++ctx.pc;
        }
    }

    private static class DoRegIndex2 extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.indexReg = getIndex(frame.compilerData.itsICode, frame.pc);
            frame.pc += 2;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.indexReg = ctx.getIndex(ctx.pc);
            ctx.out.println(tname + " " + ctx.indexReg);
            ctx.pc += 2;
        }
    }

    private static class DoRegIndex4 extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.indexReg = getInt(frame.compilerData.itsICode, frame.pc);
            frame.pc += 4;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.indexReg = ctx.getInt(ctx.pc);
            ctx.out.println(tname + " " + ctx.indexReg);
            ctx.pc += 4;
        }
    }

    private static class DoStringCn extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.stringReg = frame.compilerData.itsStringTable[Icode.REG_STR_C0 - op];
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            String str = ctx.compilerData.itsStringTable[Icode.REG_STR_C0 - op];
            ctx.out.println(tname + " \"" + str + '"');
        }
    }

    private static class DoRegString1 extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.stringReg =
                    frame.compilerData.itsStringTable[0xFF & frame.compilerData.itsICode[frame.pc]];
            ++frame.pc;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            String str = ctx.compilerData.itsStringTable[0xFF & ctx.compilerData.itsICode[ctx.pc]];
            ctx.out.println(tname + " \"" + str + '"');
            ++ctx.pc;
        }
    }

    private static class DoRegString2 extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.stringReg =
                    frame.compilerData
                            .itsStringTable[getIndex(frame.compilerData.itsICode, frame.pc)];
            frame.pc += 2;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            String str = ctx.compilerData.itsStringTable[ctx.getIndex(ctx.pc)];
            ctx.out.println(tname + " \"" + str + '"');
            ctx.pc += 2;
        }
    }

    private static class DoRegString4 extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.stringReg =
                    frame.compilerData
                            .itsStringTable[getInt(frame.compilerData.itsICode, frame.pc)];
            frame.pc += 4;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            String str = ctx.compilerData.itsStringTable[ctx.getInt(ctx.pc)];
            ctx.out.println(tname + " \"" + str + '"');
            ctx.pc += 4;
        }
    }

    private static class DoBigIntCn extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.bigIntReg = frame.compilerData.itsBigIntTable[Icode.REG_BIGINT_C0 - op];
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            ctx.out.println(
                    tname
                            + " "
                            + ctx.compilerData.itsBigIntTable[Icode.REG_BIGINT_C0 - op].toString()
                            + 'n');
        }
    }

    private static class DoRegBigInt1 extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.bigIntReg =
                    frame.compilerData.itsBigIntTable[0xFF & frame.compilerData.itsICode[frame.pc]];
            ++frame.pc;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            BigInteger bigInt =
                    ctx.compilerData.itsBigIntTable[0xFF & ctx.compilerData.itsICode[ctx.pc]];
            ctx.out.println(tname + " " + bigInt.toString() + 'n');
            ++ctx.pc;
        }
    }

    private static class DoRegBigInt2 extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.bigIntReg =
                    frame.compilerData
                            .itsBigIntTable[getIndex(frame.compilerData.itsICode, frame.pc)];
            frame.pc += 2;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            BigInteger bigInt = ctx.compilerData.itsBigIntTable[ctx.getIndex(ctx.pc)];
            ctx.out.println(tname + " " + bigInt.toString() + 'n');
            ctx.pc += 2;
        }
    }

    private static class DoRegBigInt4 extends InstructionClass {
        @Override
        NewState execute(Context cx, CallFrame frame, InterpreterState state, int op) {
            state.bigIntReg =
                    frame.compilerData
                            .itsBigIntTable[getInt(frame.compilerData.itsICode, frame.pc)];
            frame.pc += 4;
            return null;
        }

        @Override
        void dumpICode(int op, String tname, ICodeDumpContext ctx) {
            BigInteger bigInt = ctx.compilerData.itsBigIntTable[ctx.getInt(ctx.pc)];
            ctx.out.println(tname + " " + bigInt.toString() + 'n');
            ctx.pc += 4;
        }
    }

    /**
     * Adds the new args to the bound args. Because we're unwrapping things in reverse order they
     * are actually prepended.
     */
    private static Object[] addBoundArgs(Object[] boundArgs, Object[] newArgs) {
        if (newArgs.length == 0) {
            return boundArgs;
        } else if (boundArgs == null) {
            return newArgs;
        } else {
            Object[] result = Arrays.copyOf(newArgs, boundArgs.length + newArgs.length);
            System.arraycopy(boundArgs, 0, result, newArgs.length, boundArgs.length);
            return result;
        }
    }

    private static CallFrame processThrowable(
            Context cx,
            Object throwable,
            CallFrame frame,
            int indexReg,
            boolean instructionCounting) {
        // Recovering from exception, indexReg contains
        // the index of handler

        if (indexReg >= 0) {
            // Normal exception handler, transfer
            // control appropriately

            if (frame.frozen) {
                // XXX Deal with exceptios!!!
                frame = frame.cloneFrozen();
            }

            int[] table = frame.compilerData.exceptionTable;

            frame.stackTop = frame.emptyStackTop;

            frame.pc = table[indexReg + EXCEPTION_HANDLER_SLOT];
            if (instructionCounting) {
                frame.pcPrevBranch = frame.pc;
            }

            int localShift = frame.compilerData.maxVars;
            int scopeLocal = localShift + table[indexReg + EXCEPTION_SCOPE_SLOT];
            int exLocal = localShift + table[indexReg + EXCEPTION_LOCAL_SLOT];
            frame.scope = (VarScope) frame.stack[scopeLocal];
            frame.stack[exLocal] = throwable;

            throwable = null;
        } else {
            // Continuation restoration
            @SuppressWarnings("unchecked")
            var cjump = (ContinuationJump<CallFrame, InterpreterData<?>>) throwable;

            // Clear throwable to indicate that exceptions are OK
            throwable = null;

            if (!Objects.equals(cjump.branchFrame, frame)) Kit.codeBug();

            // Check that we have at least one frozen frame
            // in the case of detached continuation restoration:
            // unwind code ensure that
            if (cjump.capturedFrame == null) Kit.codeBug();

            // Need to rewind branchFrame, capturedFrame
            // and all frames in between
            int rewindCount = cjump.capturedFrame.frameIndex + 1;
            if (cjump.branchFrame != null) {
                rewindCount -= cjump.branchFrame.frameIndex;
            }

            int enterCount = 0;
            ACallFrame<?, ?>[] enterFrames = null;

            ACallFrame<?, ?> x = cjump.capturedFrame;
            for (int i = 0; i != rewindCount; ++i) {
                if (!x.frozen) Kit.codeBug();
                if (x.useActivation) {
                    if (enterFrames == null) {
                        // Allocate enough space to store the rest
                        // of rewind frames in case all of them
                        // would require to enter
                        enterFrames = new ACallFrame[rewindCount - i];
                    }
                    enterFrames[enterCount] = x;
                    ++enterCount;
                }
                x = x.parentFrame;
            }

            while (enterCount != 0) {
                // execute enter: walk enterFrames in the reverse
                // order since they were stored starting from
                // the capturedFrame, not branchFrame
                --enterCount;
                x = enterFrames[enterCount];
                enterFrame(cx, x, ScriptRuntime.emptyArgs, true);
            }

            // Continuation jump is almost done: capturedFrame
            // points to the call to the function that captured
            // continuation, so clone capturedFrame and
            // emulate return that function with the suplied result
            frame = (CallFrame) cjump.capturedFrame.cloneFrozen();
            setCallResult(frame, cjump.result, cjump.resultDbl);
            // restart the execution
        }
        frame.throwable = throwable;
        return frame;
    }

    private static Scriptable getApplyThis(
            Context cx,
            Object[] stack,
            double[] sDbl,
            Object[] boundArgs,
            int thisIdx,
            int indexReg,
            Function target,
            CallFrame frame) {
        Object obj;
        if (indexReg != 0) {
            if (boundArgs != null && boundArgs.length > 0) {
                obj = boundArgs[0];
            } else {
                obj = stack[thisIdx];
                if (obj == DOUBLE_MARK) obj = ScriptRuntime.wrapNumber(sDbl[thisIdx]);
            }
        } else {
            obj = null;
        }
        return ScriptRuntime.getApplyOrCallThis(
                cx, target.getDeclarationScope(), obj, indexReg, target);
    }

    private static CallFrame initFrame(
            Context cx,
            VarScope callerScope,
            Scriptable thisObj,
            Scriptable homeObj,
            Object[] args,
            double[] argsDbl,
            Object[] boundArgs,
            int argShift,
            int argCount,
            ScriptOrFn<?> fnOrScript,
            InterpreterData<?> code,
            CallFrame parentFrame) {
        CallFrame frame =
                new CallFrame(
                        cx,
                        thisObj,
                        fnOrScript,
                        code,
                        parentFrame,
                        parentFrame == null
                                ? cx.lastInterpreterFrame
                                : parentFrame.previousInterpreterFrame);
        frame.initializeArgs(
                cx, callerScope, args, argsDbl, boundArgs, argShift, argCount, homeObj);
        enterFrame(cx, frame, args, false);
        return frame;
    }

    private static void setCallResult(CallFrame frame, Object callResult, double callResultDbl) {
        if (frame.savedCallOp == Token.CALL || frame.savedCallOp == Icode.CALL_ON_SUPER) {
            frame.stack[frame.stackTop] = callResult;
            frame.doubleStack[frame.stackTop] = callResultDbl;
        } else if (frame.savedCallOp == Token.NEW) {
            // If construct returns scriptable,
            // then it replaces on stack top saved original instance
            // of the object.
            if (callResult instanceof Scriptable) {
                frame.stack[frame.stackTop] = callResult;
            }
        } else {
            Kit.codeBug();
        }
        frame.savedCallOp = 0;
    }

    public static NativeContinuation captureContinuation(Context cx) {
        if (cx.lastInterpreterFrame == null || !(cx.lastInterpreterFrame instanceof CallFrame)) {
            throw new IllegalStateException("Interpreter frames not found");
        }
        return captureContinuation(cx, (CallFrame) cx.lastInterpreterFrame, true);
    }

    private static NativeContinuation captureContinuation(
            Context cx, CallFrame frame, boolean requireContinuationsTopFrame) {
        NativeContinuation c = new NativeContinuation();
        ScriptRuntime.setObjectProtoAndParent(c, ScriptRuntime.getTopCallScope(cx));

        // Make sure that all frames are frozen
        CallFrame x = frame;
        CallFrame outermost = frame;
        while (x != null && !x.frozen) {
            x.frozen = true;
            // Allow to GC unused stack space
            for (int i = x.stackTop + 1; i != x.stack.length; ++i) {
                // Allow to GC unused stack space
                x.stack[i] = null;
                x.stackAttributes[i] = ScriptableObject.EMPTY;
            }
            if (x.savedCallOp == Token.CALL || x.savedCallOp == Icode.CALL_ON_SUPER) {
                // the call will always overwrite the stack top with the result
                x.stack[x.stackTop] = null;
            } else {
                if (x.savedCallOp != Token.NEW) Kit.codeBug();
                // the new operator uses stack top to store the constructed
                // object so it shall not be cleared: see comments in
                // setCallResult
            }
            outermost = x;
            x = x.parentFrame;
        }

        if (requireContinuationsTopFrame) {
            while (outermost.parentFrame != null) outermost = outermost.parentFrame;

            if (!outermost.isContinuationsTopFrame) {
                throw new IllegalStateException(
                        "Cannot capture continuation "
                                + "from JavaScript code not called directly by "
                                + "executeScriptWithContinuations or "
                                + "callFunctionWithContinuations");
            }
        }

        c.initImplementation(frame);
        return c;
    }

    private static int stack_int32(CallFrame frame, int i) {
        Object x = frame.stack[i];
        if (x == UniqueTag.DOUBLE_MARK) {
            return ScriptRuntime.toInt32(frame.doubleStack[i]);
        }
        return ScriptRuntime.toInt32(x);
    }

    private static double stack_double(CallFrame frame, int i) {
        Object x = frame.stack[i];
        if (x != UniqueTag.DOUBLE_MARK) {
            return ScriptRuntime.toNumber(x);
        }
        return frame.doubleStack[i];
    }

    private static Number stack_numeric(CallFrame frame, int i) {
        Object x = frame.stack[i];
        if (x != UniqueTag.DOUBLE_MARK) {
            return ScriptRuntime.toNumeric(x);
        }
        return frame.doubleStack[i];
    }

    private static boolean stack_boolean(CallFrame frame, int i) {
        Object x = frame.stack[i];
        if (Boolean.TRUE.equals(x)) {
            return true;
        } else if (Boolean.FALSE.equals(x)) {
            return false;
        } else if (x == UniqueTag.DOUBLE_MARK) {
            double d = frame.doubleStack[i];
            return !Double.isNaN(d) && d != 0.0;
        } else if (x == null || x == Undefined.instance) {
            return false;
        } else if (x instanceof BigInteger) {
            return !x.equals(BigInteger.ZERO);
        } else if (x instanceof Number) {
            double d = ((Number) x).doubleValue();
            return (!Double.isNaN(d) && d != 0.0);
        } else {
            return ScriptRuntime.toBoolean(x);
        }
    }

    private static Object[] getArgsArray(Object[] stack, double[] sDbl, int shift, int count) {
        return getArgsArray(stack, sDbl, new Object[0], 0, shift, count);
    }

    static Object[] getArgsArray(
            Object[] stack, double[] sDbl, Object[] bound, int bCount, int shift, int count) {
        if (count == 0) {
            return ScriptRuntime.emptyArgs;
        }
        Object[] args = new Object[count];
        for (int i = 0; i < bCount; i++) {
            args[i] = bound[i];
        }

        for (int i = bCount; i != count; ++i, ++shift) {
            Object val = stack[shift];
            if (val == UniqueTag.DOUBLE_MARK) {
                val = ScriptRuntime.wrapNumber(sDbl[shift]);
            }
            args[i] = val;
        }
        return args;
    }

    private static void addInstructionCount(Context cx, CallFrame frame, int extra) {
        cx.instructionCount += frame.pc - frame.pcPrevBranch + extra;
        if (cx.instructionCount > cx.instructionThreshold) {
            cx.observeInstructionCount(cx.instructionCount);
            cx.instructionCount = 0;
        }
    }

    private static JSFunction createClosure(Context cx, CallFrame frame, int index) {
        var desc = frame.fnOrScript.getDescriptor().getFunction(index);
        boolean isArrow = desc.getFunctionType() == FunctionNode.ARROW_FUNCTION;
        var homeObject = isArrow ? frame.fnOrScript.getHomeObject() : null;
        JSFunction f = new JSFunction(cx, frame.scope, desc, frame.thisObj, homeObject);
        return f;
    }

    private static JSFunction createMethod(
            Context cx, CallFrame frame, int index, Scriptable homeObject) {
        var desc = frame.fnOrScript.getDescriptor().getFunction(index);
        boolean isArrow = desc.getFunctionType() == FunctionNode.ARROW_FUNCTION;
        JSFunction f = new JSFunction(cx, frame.scope, desc, frame.thisObj, homeObject);
        return f;
    }
}
