/* -*- Mode: java; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.javascript;

import static org.mozilla.javascript.ClassDescriptor.Builder.value;
import static org.mozilla.javascript.ClassDescriptor.Destination.PROTO;
import static org.mozilla.javascript.Symbol.Kind.REGULAR;

import java.io.Serial;
import java.util.EnumSet;
import org.mozilla.javascript.xml.XMLObject;

/**
 * The base class for Function objects. That is one of two purposes. It is also the prototype for
 * every "function" defined except those that are used as GeneratorFunctions via the ES6 "function
 * *" syntax.
 *
 * <p>See ECMA 15.3.
 *
 * @author Norris Boyd
 */
public class BaseFunction extends ScriptableObject implements Function {
    @Serial private static final long serialVersionUID = 5311394446546053859L;

    private static final Object FUNCTION_TAG = "Function";
    private static final String FUNCTION_CLASS = "Function";
    static final SymbolKey GENERATOR_FUNCTION_CLASS =
            new SymbolKey("GeneratorFunctionPrototype", REGULAR);

    private static final String APPLY_TAG = "APPLY_TAG";
    private static final String CALL_TAG = "CALL_TAG";
    private static final String PROTOTYPE_PROPERTY_NAME = "prototype";

    private static final ClassDescriptor DESCRIPTOR;
    private static final ClassDescriptor ES6_DESCRIPTOR;
    private static final ClassDescriptor GENERATOR_DESCRIPTOR;
    private static final JSDescriptor<JSFunction> APPLY_DESCRIPTOR;
    private static final JSDescriptor<JSFunction> CALL_DESCRIPTOR;

    static {
        var builder =
                new ClassDescriptor.Builder(
                                FUNCTION_CLASS,
                                1,
                                BaseFunction::js_constructor,
                                BaseFunction::js_constructor)
                        .withMethod(PROTO, "call", 1, BaseFunction::js_call)
                        .withMethod(PROTO, "apply", 2, BaseFunction::js_apply)
                        .withMethod(PROTO, "bind", 1, BaseFunction::js_bind)
                        .withMethod(PROTO, "toSource", 1, BaseFunction::js_toSource)
                        .withMethod(PROTO, "toString", 0, BaseFunction::js_toString)
                        .withMethod(
                                PROTO,
                                SymbolKey.HAS_INSTANCE,
                                1,
                                BaseFunction::js_hasInstance,
                                DONTENUM | READONLY | PERMANENT,
                                DONTENUM | READONLY);

        DESCRIPTOR = builder.build();
        ES6_DESCRIPTOR =
                builder.withProp(
                                PROTO,
                                "arguments",
                                BaseFunction::js_protoArgumentsGetter,
                                BaseFunction::js_protoArgumentsSetter,
                                DONTENUM | READONLY)
                        // HtmlUnit
                        .withProp(
                                PROTO,
                                "caller",
                                BaseFunction::js_protoCallerGetter,
                                BaseFunction::js_protoCallerSetter,
                                DONTENUM | READONLY)
                        // HtmlUnit
                        .build();

        APPLY_DESCRIPTOR = DESCRIPTOR.findProtoDesc("apply");
        CALL_DESCRIPTOR = DESCRIPTOR.findProtoDesc("call");

        GENERATOR_DESCRIPTOR =
                new ClassDescriptor.Builder(
                                GENERATOR_FUNCTION_CLASS,
                                "GeneratorFunction",
                                1,
                                BaseFunction::js_gen_constructor,
                                BaseFunction::js_gen_constructor)
                        .withProp(
                                PROTO,
                                SymbolKey.TO_STRING_TAG,
                                value("GeneratorFunction", READONLY | DONTENUM))
                        .build();
    }

    static JSFunction init(Context cx, VarScope scope, boolean sealed) {
        var proto =
                new LambdaFunction(
                        scope, "", 0, null, (lcx, lscope, lthisObj, largs) -> Undefined.instance);

        if (cx.getLanguageVersion() < Context.VERSION_ES6) {
            return DESCRIPTOR.buildConstructor(cx, scope, proto, sealed);
        } else {
            return ES6_DESCRIPTOR.buildConstructor(cx, scope, proto, sealed);
        }
    }

    /**
     * @deprecated Use {@link #init(Context, VarScope, boolean)} instead
     */
    @Deprecated
    static void init(VarScope scope, boolean sealed) {
        init(Context.getContext(), scope, sealed);
    }

    static Object initAsGeneratorFunction(Context cx, VarScope scope, boolean sealed) {
        var proto = new NativeObject();

        return GENERATOR_DESCRIPTOR.buildConstructor(
                cx,
                scope,
                proto,
                sealed,
                (c, ctor) -> {
                    VarScope top = ScriptableObject.getTopLevelScope(scope);

                    var function = (Scriptable) ScriptableObject.getProperty(scope, FUNCTION_CLASS);
                    var functionProto =
                            (Scriptable)
                                    ScriptableObject.getProperty(function, PROTOTYPE_PROPERTY_NAME);
                    proto.setPrototype(functionProto);

                    var generatorProto =
                            ScriptableObject.getTopScopeValue(top, ES6Generator.GENERATOR_TAG);

                    proto.setAttributes("constructor", DONTENUM | READONLY);
                    proto.defineProperty("prototype", generatorProto, READONLY | DONTENUM);
                });
    }

    public BaseFunction() {
        createProperties();
    }

    public BaseFunction(boolean isGenerator) {
        createProperties();
        this.isGeneratorFunction = isGenerator;
    }

    public BaseFunction(VarScope scope, Scriptable prototype) {
        super(scope, prototype);
        createProperties();
        ScriptRuntime.setBuiltinProtoAndParent(this, scope, TopLevel.Builtins.Function);
    }

    protected void createProperties() {
        ScriptableObject.defineBuiltInProperty(
                this, "length", DONTENUM | READONLY, BaseFunction::lengthGetter);
        ScriptableObject.defineBuiltInProperty(
                this,
                "name",
                DONTENUM | READONLY,
                BaseFunction::nameGetter,
                BaseFunction::nameSetter);

        Context cx = Context.getCurrentContext();
        if (cx == null || !cx.isStrictMode()) {
            ScriptableObject.defineBuiltInProperty(
                    this, "arity", PERMANENT | DONTENUM | READONLY, BaseFunction::arityGetter);

            if (cx == null || cx.getLanguageVersion() < Context.VERSION_ES6) {
                ScriptableObject.defineBuiltInProperty(
                        this,
                        "arguments",
                        PERMANENT | DONTENUM,
                        BaseFunction::argumentsGetter,
                        BaseFunction::argumentsSetter);
            }
        }
    }

    private static Object lengthGetter(BaseFunction function, Scriptable start) {
        return function.getLength();
    }

    private static Object arityGetter(BaseFunction function, Scriptable start) {
        return function.getArity();
    }

    private static Object argumentsGetter(BaseFunction function, Scriptable start) {
        return function.getArguments();
    }

    private static boolean argumentsSetter(
            BaseFunction function,
            Object value,
            Scriptable owner,
            Scriptable start,
            boolean isThrow) {
        function.argumentsObj = value;
        return true;
    }

    private static Object nameGetter(BaseFunction function, Scriptable start) {
        return function.nameValue != null ? function.nameValue : function.getFunctionName();
    }

    private static boolean nameSetter(
            BaseFunction function,
            Object value,
            Scriptable owner,
            Scriptable start,
            boolean isThrow) {
        function.nameValue = value;
        return true;
    }

    /** Forces setting the function's name, bypassing all "readonly" checks. */
    void setFunctionName(String name) {
        nameValue = name;
    }

    protected void createPrototypeProperty() {
        try (var map = startCompoundOp(true)) {
            createPrototypeProperty(map);
        }
    }

    protected void createPrototypeProperty(CompoundOperationMap<Scriptable> compoundOp) {
        compoundOp.compute(
                this,
                compoundOp,
                PROTOTYPE_PROPERTY_NAME,
                0,
                (k, i, s, m, o) -> {
                    if (s == null) {
                        return new BuiltInSlot<BaseFunction>(
                                PROTOTYPE_PROPERTY_NAME,
                                0,
                                prototypePropertyAttributes,
                                this,
                                BaseFunction::prototypeGetter,
                                BaseFunction::prototypeSetter,
                                BaseFunction::prototypeAttrSetter,
                                BaseFunction::prototypeDescSetter);
                    }
                    return s;
                });
    }

    private static Object prototypeGetter(BaseFunction function, Scriptable start) {
        return function.getPrototypeProperty();
    }

    private static boolean prototypeSetter(
            BaseFunction function,
            Object value,
            Scriptable owner,
            Scriptable start,
            boolean isThrow) {
        function.prototypeProperty = value == null ? UniqueTag.NULL_VALUE : value;
        return true;
    }

    private static void prototypeAttrSetter(BaseFunction function, int attributes) {
        function.prototypePropertyAttributes = attributes;
    }

    protected static boolean prototypeDescSetter(
            BaseFunction builtIn,
            BuiltInSlot<BaseFunction> current,
            Object id,
            ScriptableObject.DescriptorInfo info,
            boolean checkValid,
            Object key,
            int index) {
        try (var map = builtIn.startCompoundOp(true)) {
            return ScriptableObject.defineOrdinaryProperty(
                    (o, i, k, e, m, s) -> {
                        if (i.value != NOT_FOUND) {
                            builtIn.prototypeProperty =
                                    i.value == null ? UniqueTag.NULL_VALUE : i.value;
                        }
                        return s;
                    },
                    builtIn,
                    map,
                    id,
                    info,
                    checkValid,
                    key,
                    index);
        }
    }

    static DescriptorInfo createThrowingProp(Context cx, VarScope scope, ScriptableObject obj) {
        var thrower = ScriptRuntime.typeErrorThrower(scope);
        return new DescriptorInfo(false, NOT_FOUND, true, thrower, thrower, null);
    }

    protected final boolean defaultHas(String name) {
        return super.has(name, this);
    }

    protected final Object defaultGet(String name) {
        return super.get(name, this);
    }

    protected final void defaultPut(String name, Object value) {
        super.put(name, this, value);
    }

    @Override
    public String getClassName() {
        return isGeneratorFunction() ? "GeneratorFunction" : FUNCTION_CLASS;
    }

    // Generated code will override this
    protected boolean isGeneratorFunction() {
        return isGeneratorFunction;
    }

    // Generated code will override this
    protected boolean hasDefaultParameters() {
        return false;
    }

    /**
     * Gets the value returned by calling the typeof operator on this object.
     *
     * @see ScriptableObject#getTypeOf()
     * @return "function" or "undefined" if {@link #avoidObjectDetection()} returns {@code true}
     */
    @Override
    public String getTypeOf() {
        return avoidObjectDetection() ? "undefined" : "function";
    }

    /**
     * Implements the instanceof operator for JavaScript Function objects.
     *
     * <p><code>
     * foo = new Foo();<br>
     * foo instanceof Foo;  // true<br>
     * </code>
     *
     * @param instance The value that appeared on the LHS of the instanceof operator
     * @return true if the "prototype" property of "this" appears in value's prototype chain
     */
    @Override
    public boolean hasInstance(Scriptable instance) {
        Context cx = Context.getCurrentContext();

        // Attempt to call custom Symbol.hasInstance implementation if present

        Object hasInstanceMethod = ScriptRuntime.getObjectElem(this, SymbolKey.HAS_INSTANCE, cx);
        if (hasInstanceMethod instanceof Callable) {
            return ScriptRuntime.toBoolean(
                    ((Callable) hasInstanceMethod)
                            .call(cx, getParentScope(), this, new Object[] {instance}));
        }

        Object protoProp = ScriptableObject.getProperty(this, PROTOTYPE_PROPERTY_NAME);
        if (protoProp instanceof Scriptable) {
            return ScriptRuntime.jsDelegatesTo(instance, (Scriptable) protoProp);
        }
        throw ScriptRuntime.typeErrorById("msg.instanceof.bad.prototype", getFunctionName());
    }

    protected static final int Id_length = 1,
            Id_arity = 2,
            Id_name = 3,
            Id_prototype = 4,
            Id_arguments = 5,
            MAX_INSTANCE_ID = 5;

    static boolean isApply(Callable f) {
        if (f instanceof KnownBuiltInFunction kf) {
            var tag = kf.getTag();
            return tag == APPLY_TAG;
        }
        if (f instanceof JSFunction jsf) {
            return jsf.getDescriptor() == APPLY_DESCRIPTOR;
        }
        return false;
    }

    static boolean isApplyOrCall(Callable f) {
        if (f instanceof KnownBuiltInFunction) {
            var kf = (KnownBuiltInFunction) f;
            var tag = kf.getTag();
            return tag == APPLY_TAG || tag == CALL_TAG;
        }
        if (f instanceof JSFunction) {
            var desc = ((JSFunction) f).getDescriptor();
            return desc == APPLY_DESCRIPTOR || desc == CALL_DESCRIPTOR;
        }
        return false;
    }

    private static Object js_hasInstance(
            Context cx, JSFunction f, Object nt, VarScope s, Object thisObj, Object[] args) {
        if (!(thisObj instanceof Callable && thisObj instanceof Scriptable)) {
            return false;
        }
        Object protoProp = null;
        if (thisObj instanceof BoundFunction)
            protoProp =
                    ((JSFunction) ((BoundFunction) thisObj).getTargetFunction())
                            .getPrototypeProperty();
        else {
            protoProp = ScriptableObject.getProperty((Scriptable) thisObj, PROTOTYPE_PROPERTY_NAME);
        }

        if (ScriptRuntime.isObject(protoProp) || protoProp instanceof XMLObject) {
            if (args.length > 0 && args[0] instanceof Scriptable) {
                Scriptable obj = (Scriptable) args[0];

                return ScriptRuntime.jsDelegatesTo(obj, (Scriptable) protoProp);
            }
            return false; // NOT_FOUND, null etc.
        }

        throw ScriptRuntime.typeErrorById(
                "msg.instanceof.bad.prototype",
                (thisObj instanceof BaseFunction)
                        ? ((BaseFunction) thisObj).getFunctionName()
                        : "unknown");
    }

    private static Object js_bind(
            Context cx, JSFunction f, Object nt, VarScope s, Object thisObj, Object[] args) {
        if (!(thisObj instanceof Callable)) {
            throw ScriptRuntime.notFunctionError(thisObj);
        }
        Callable targetFunction = (Callable) thisObj;
        int argc = args.length;
        final Scriptable boundThis;
        final Object[] boundArgs;
        if (argc > 0) {
            boundThis = ScriptRuntime.toObjectOrNull(cx, args[0], s);
            boundArgs = new Object[argc - 1];
            System.arraycopy(args, 1, boundArgs, 0, argc - 1);
        } else {
            boundThis = null;
            boundArgs = ScriptRuntime.emptyArgs;
        }
        return new BoundFunction(cx, s, targetFunction, boundThis, boundArgs);
    }

    private static Object js_apply(
            Context cx, JSFunction f, Object nt, VarScope s, Object thisObj, Object[] args) {
        var thisArg = ScriptRuntime.toObject(f.getDeclarationScope(), thisObj);
        return ScriptRuntime.applyOrCall(true, cx, f.getDeclarationScope(), thisArg, args);
    }

    private static Object js_call(
            Context cx, JSFunction f, Object nt, VarScope s, Object thisObj, Object[] args) {
        var thisArg = ScriptRuntime.toObject(f.getDeclarationScope(), thisObj);
        return ScriptRuntime.applyOrCall(false, cx, f.getDeclarationScope(), thisArg, args);
    }

    private static Object js_toSource(
            Context cx, JSFunction f, Object nt, VarScope s, Object thisObj, Object[] args) {
        BaseFunction realf = realFunction(thisObj, "toSource");
        int indent = 0;
        EnumSet<DecompilerFlag> flags = EnumSet.of(DecompilerFlag.TO_SOURCE);
        if (args.length != 0) {
            indent = ScriptRuntime.toInt32(args[0]);
            if (indent >= 0) {
                flags = EnumSet.noneOf(DecompilerFlag.class);
            } else {
                indent = 0;
            }
        }
        return realf.decompile(indent, flags);
    }

    private static Object js_toString(
            Context cx, JSFunction f, Object nt, VarScope s, Object thisObj, Object[] args) {
        BaseFunction realf = realFunction(thisObj, "toString");
        int indent = ScriptRuntime.toInt32(args, 0);
        return realf.decompile(indent, EnumSet.noneOf(DecompilerFlag.class));
    }

    private static Scriptable js_constructor(
            Context cx, JSFunction f, Object nt, VarScope s, Object thisObj, Object[] args) {
        // legado
        return jsConstructor(cx, dynamicConstructorScope(cx, f), args, false);
        // end legado
    }

    private static Scriptable js_gen_constructor(
            Context cx, JSFunction f, Object nt, VarScope s, Object thisObj, Object[] args) {
        // legado
        return jsConstructor(cx, dynamicConstructorScope(cx, f), args, true);
        // end legado
    }

    // legado: with FEATURE_LEGADO_DYNAMIC_EVAL_REALM, functions created via the Function
    // constructor close over the current top call scope (dynamic, pre-realm-separation
    // behavior) instead of the intrinsic's declaration realm
    private static VarScope dynamicConstructorScope(Context cx, JSFunction f) {
        if (cx.hasFeature(Context.FEATURE_LEGADO_DYNAMIC_EVAL_REALM)
                && ScriptRuntime.hasTopCall(cx)) {
            return ScriptRuntime.getTopCallScope(cx);
        }
        return f.getDeclarationScope();
    }
    // end legado

    private static BaseFunction realFunction(Object thisObj, String functionName) {
        if (thisObj == null) {
            throw ScriptRuntime.notFunctionError(null);
        }
        if (thisObj instanceof Scriptable) {
            Object x = ((Scriptable) thisObj).getDefaultValue(ScriptRuntime.FunctionClass);
            if (x instanceof Delegator) {
                x = ((Delegator) x).getDelegee();
            }
            return ensureType(x, BaseFunction.class, functionName);
        }
        return ensureType(thisObj, BaseFunction.class, functionName);
    }

    /** Make value as DontEnum, DontDelete, ReadOnly prototype property of this Function object */
    public void setImmunePrototypeProperty(Object value) {
        if ((prototypePropertyAttributes & READONLY) != 0) {
            throw new IllegalStateException();
        }
        prototypeProperty = (value != null) ? value : UniqueTag.NULL_VALUE;
        createPrototypeProperty();
        setAttributes(PROTOTYPE_PROPERTY_NAME, DONTENUM | PERMANENT | READONLY);
    }

    public Scriptable getClassPrototype() {
        Object protoVal = getPrototypeProperty();
        if (protoVal instanceof Scriptable) {
            return (Scriptable) protoVal;
        }
        return ScriptableObject.getObjectPrototype(getDeclarationScope());
    }

    /** Should be overridden. */
    @Override
    public Object call(Context cx, VarScope scope, Scriptable thisObj, Object[] args) {
        return Undefined.instance;
    }

    @Override
    public Scriptable construct(Context cx, VarScope scope, Object[] args) {
        if (cx.getLanguageVersion() >= Context.VERSION_ES6 && this.getHomeObject() != null) {
            // Only methods have home objects associated with them
            throw ScriptRuntime.typeErrorById("msg.not.ctor", getFunctionName());
        }

        Scriptable result = createObject(cx, scope);
        if (result == null) {
            Object val = call(cx, scope, null, args);
            if (!(val instanceof Scriptable)) {
                // It is program error not to return Scriptable from
                // the call method if createObject returns null.
                throw new IllegalStateException(
                        "Bad implementation of call as constructor, name="
                                + getFunctionName()
                                + " in "
                                + getClass().getName());
            }
            result = (Scriptable) val;
            if (result.getPrototype() == null) {
                Scriptable proto = getClassPrototype();
                if (result != proto) {
                    result.setPrototype(proto);
                }
            }
            if (result.getParentScope() == null) {
                VarScope parent = getParentScope();
                result.setParentScope(parent);
            }
        } else {
            Object val = call(cx, scope, result, args);
            if (val instanceof Scriptable) {
                result = (Scriptable) val;
            }
        }
        return result;
    }

    /**
     * Creates new script object. The default implementation of {@link #construct} uses this method
     * to to get the value for {@code thisObj} argument when invoking {@link #call}. The method is
     * allowed to return {@code null} to indicate that {@link #call} will create a new object
     * itself. In this case {@link #construct} will set scope and prototype on the result {@link
     * #call} unless they are already set.
     */
    public Scriptable createObject(Context cx, VarScope scope) {
        Scriptable newInstance = new NativeObject();
        newInstance.setPrototype(getClassPrototype());
        newInstance.setParentScope(getParentScope());
        return newInstance;
    }

    /**
     * Decompile the source information associated with this js function/script back into a string.
     *
     * @param indent How much to indent the decompiled result.
     * @param flags Flags specifying format of decompilation output.
     */
    String decompile(int indent, EnumSet<DecompilerFlag> flags) {
        StringBuilder sb = new StringBuilder();
        boolean justbody = flags.contains(DecompilerFlag.ONLY_BODY);
        if (!justbody) {
            sb.append("function ");
            sb.append(getFunctionName());
            // HtmlUnit
            // sb.append("() {\n\t");
            sb.append("() {\n    ");
            // end HtmlUnit
        }
        sb.append("[native code]\n");
        if (!justbody) {
            // HtmlUnit
            // sb.append("}\n");
            sb.append("}");
            // end HtmlUnit
        }
        return sb.toString();
    }

    public int getArity() {
        return 0;
    }

    public int getLength() {
        return 0;
    }

    private static Object js_protoArgumentsGetter(Scriptable thisObj) {
        return LambdaConstructor.convertThisObject(thisObj, BaseFunction.class).getArguments();
    }

    private static void js_protoArgumentsSetter(Scriptable thisObj, Object value) {
        LambdaConstructor.convertThisObject(thisObj, BaseFunction.class).setArguments(value);
    }

    // HtmlUnit
    private static Object js_protoCallerGetter(Scriptable thisObj) {
        return LambdaConstructor.convertThisObject(thisObj, BaseFunction.class).getCaller();
    }

    private static void js_protoCallerSetter(Scriptable thisObj, Object value) {
        LambdaConstructor.convertThisObject(thisObj, BaseFunction.class).setCaller(value);
    }

    Object getCaller() {
        throw ScriptRuntime.typeErrorById("msg.op.not.allowed");
    }

    void setCaller(Object caller) {
        throw ScriptRuntime.typeErrorById("msg.op.not.allowed");
    }
    // HtmlUnit

    public String getFunctionName() {
        return "";
    }

    /**
     * Sets the attributes of the "name", "length", and "arity" properties, which differ for many
     * native objects.
     */
    public void setStandardPropertyAttributes(int attributes) {
        setAttributes("name", attributes);
        setAttributes("length", attributes);
        setAttributes("arity", attributes);
    }

    public void setPrototypePropertyAttributes(int attributes) {
        prototypePropertyAttributes = attributes;
        getMap().compute(
                        this,
                        PROTOTYPE_PROPERTY_NAME,
                        0,
                        (k, i, s, m, o) -> {
                            if (s != null) {
                                s.setAttributes(attributes);
                            }
                            return s;
                        });
    }

    protected boolean hasPrototypeProperty() {
        return prototypeProperty != null && prototypeProperty != UniqueTag.NOT_FOUND;
    }

    public Object getPrototypeProperty() {
        Object result = prototypeProperty;
        if (result == null || result == UniqueTag.NOT_FOUND) {
            result = Undefined.instance;
        } else if (result == UniqueTag.NULL_VALUE) {
            result = null;
        }
        return result;
    }

    protected void setPrototypeProperty(Object prototype) {
        if (prototype != null) {
            createPrototypeProperty();
            this.prototypeProperty = prototype;
        } else {
            prototypeProperty = UniqueTag.NOT_FOUND;
        }
    }

    protected synchronized Object setupDefaultPrototype(VarScope scope) {
        if (!has(PROTOTYPE_PROPERTY_NAME, this)) {
            createPrototypeProperty();
        }
        NativeObject obj = new NativeObject();
        obj.setParentScope(getParentScope());

        // put the prototype property into the object now, then in the
        // wacky case of a user defining a function Object(), we don't
        // get an infinite loop trying to find the prototype.
        prototypeProperty = obj;
        Scriptable proto;
        if (isGeneratorFunction()) {
            // For generator functions, the .prototype property's [[Prototype]]
            // should be %GeneratorPrototype%, not Object.prototype
            VarScope top = ScriptableObject.getTopLevelScope(scope);
            Object generatorProto =
                    ScriptableObject.getTopScopeValue(top, ES6Generator.GENERATOR_TAG);
            if (generatorProto instanceof Scriptable) {
                proto = (Scriptable) generatorProto;
            } else {
                proto = getObjectPrototype(getDeclarationScope()); // fallback
            }
        } else {
            proto = getObjectPrototype(getDeclarationScope());
        }
        if (proto != obj) {
            // not the one we just made, it must remain grounded
            obj.setPrototype(proto);
        }

        obj.defineProperty("constructor", this, DONTENUM);
        return obj;
    }

    Object getArguments() {
        // <Function name>.arguments is deprecated, so we use a slow
        // way of getting it that doesn't add to the invocation cost.
        // TODO: add warning, error based on version
        if (argumentsObj != NOT_FOUND) {
            // Should after changing <Function name>.arguments its
            // activation still be available during Function call?
            // This code assumes it should not:
            // defaultGet("arguments") != NOT_FOUND
            // means assigned arguments
            return argumentsObj;
        }
        Context cx = Context.getContext();
        NativeCall activation = ScriptRuntime.findFunctionActivation(cx, this);
        // return (activation == null) ? null : activation.get("arguments", activation);
        if (activation == null) {
            return null;
        }
        if (activation.function.isStrict() && cx.getLanguageVersion() >= Context.VERSION_ES6) {
            ScriptRuntime.ThrowTypeError.throwNotAllowed();
        }
        Object arguments = activation.get("arguments", activation);
        if (arguments instanceof Arguments && cx.getLanguageVersion() >= Context.VERSION_ES6) {
            return new Arguments.ReadonlyArguments((Arguments) arguments, cx);
        }
        return arguments;
    }

    void setArguments(Object caller) {}

    private static Scriptable jsConstructor(
            Context cx, VarScope scope, Object[] args, boolean isGeneratorFunction) {
        int arglen = args.length;
        StringBuilder sourceBuf = new StringBuilder();

        sourceBuf.append("function ");
        if (isGeneratorFunction) {
            sourceBuf.append("* ");
        }
        sourceBuf.append("anonymous(");

        // Append arguments as coma separated strings
        for (int i = 0; i < arglen - 1; i++) {
            if (i > 0) {
                sourceBuf.append(',');
            }
            sourceBuf.append(ScriptRuntime.toString(args[i]));
        }
        sourceBuf.append(") {");
        if (arglen != 0) {
            // append function body
            String funBody = ScriptRuntime.toString(args[arglen - 1]);
            sourceBuf.append(funBody);
        }
        sourceBuf.append("\n}");
        String source = sourceBuf.toString();

        int[] linep = new int[1];
        String filename = Context.getSourcePositionFromStack(linep);
        if (filename == null) {
            filename = "<eval'ed string>";
            linep[0] = 1;
        }

        String sourceURI = ScriptRuntime.makeUrlForGeneratedScript(false, filename, linep[0]);

        TopLevel global = ScriptableObject.getTopLevelScope(scope);

        ErrorReporter reporter;
        reporter = DefaultErrorReporter.forEval(cx.getErrorReporter());

        Evaluator evaluator = Context.createInterpreter();
        if (evaluator == null) {
            throw new JavaScriptException("Interpreter not present", filename, linep[0]);
        }

        // Compile with explicit interpreter instance to force interpreter
        // mode.
        return cx.compileFunction(global, source, evaluator, reporter, sourceURI, 1, null);
    }

    public void setHomeObject(Scriptable homeObject) {
        this.homeObject = homeObject;
    }

    public Scriptable getHomeObject() {
        return homeObject;
    }

    @Override
    public boolean isConstructor() {
        return !(Context.getCurrentContext().getLanguageVersion() >= Context.VERSION_ES6
                && this.getHomeObject() != null);
    }

    private static final int Id_constructor = 1,
            Id_toString = 2,
            Id_toSource = 3,
            Id_apply = 4,
            Id_call = 5,
            Id_bind = 6,
            SymbolId_hasInstance = 7,
            MAX_PROTOTYPE_ID = SymbolId_hasInstance;

    private Object prototypeProperty;
    private Object argumentsObj = NOT_FOUND;
    private Object nameValue = null;
    private boolean isGeneratorFunction = false;
    private Scriptable homeObject = null;

    // For function object instances, attributes are
    //  {configurable:false, enumerable:false};
    // see ECMA 15.3.5.2
    private int prototypePropertyAttributes = PERMANENT | DONTENUM;
}
